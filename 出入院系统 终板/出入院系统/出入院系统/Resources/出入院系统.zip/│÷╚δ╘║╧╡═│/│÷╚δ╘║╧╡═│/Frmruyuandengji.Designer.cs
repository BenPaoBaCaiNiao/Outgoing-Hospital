﻿namespace 出入院系统
{
    partial class Frmruyuandengji
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_keshi = new System.Windows.Forms.TextBox();
            this.but_chakan = new System.Windows.Forms.Button();
            this.txb_menzhenNo = new System.Windows.Forms.TextBox();
            this.txb_menzhenday = new System.Windows.Forms.TextBox();
            this.lb_menzhenday = new System.Windows.Forms.Label();
            this.txb_zhenduandetail = new System.Windows.Forms.TextBox();
            this.txb_zhenduanma = new System.Windows.Forms.TextBox();
            this.lb_menzhenNo = new System.Windows.Forms.Label();
            this.lb_zhendangdetail = new System.Windows.Forms.Label();
            this.lb_zhenduanma = new System.Windows.Forms.Label();
            this.lb_keshi = new System.Windows.Forms.Label();
            this.dt_ruyuanday = new System.Windows.Forms.DateTimePicker();
            this.txb_ruyuantime = new System.Windows.Forms.TextBox();
            this.lb_zuyuanNo = new System.Windows.Forms.Label();
            this.lb_relationname = new System.Windows.Forms.Label();
            this.dt_birthday = new System.Windows.Forms.DateTimePicker();
            this.txb_relation = new System.Windows.Forms.TextBox();
            this.lb_relation = new System.Windows.Forms.Label();
            this.txb_zuyuanNo = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.rb_female = new System.Windows.Forms.RadioButton();
            this.lb_ruyuanday = new System.Windows.Forms.Label();
            this.rb_male = new System.Windows.Forms.RadioButton();
            this.but_chaxun = new System.Windows.Forms.Button();
            this.txb_country = new System.Windows.Forms.TextBox();
            this.lb_ruyuantime = new System.Windows.Forms.Label();
            this.lb_country = new System.Windows.Forms.Label();
            this.txb_minzhu = new System.Windows.Forms.TextBox();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_minzhu = new System.Windows.Forms.Label();
            this.txb_name = new System.Windows.Forms.TextBox();
            this.txb_relationname = new System.Windows.Forms.TextBox();
            this.txb_address = new System.Windows.Forms.TextBox();
            this.lb_idNo = new System.Windows.Forms.Label();
            this.txb_phone = new System.Windows.Forms.TextBox();
            this.txb_idNo = new System.Windows.Forms.TextBox();
            this.lb_marry = new System.Windows.Forms.Label();
            this.txb_marry = new System.Windows.Forms.TextBox();
            this.lb_job = new System.Windows.Forms.Label();
            this.txb_job = new System.Windows.Forms.TextBox();
            this.lb_birthday = new System.Windows.Forms.Label();
            this.lb_jistyle = new System.Windows.Forms.Label();
            this.lb_address = new System.Windows.Forms.Label();
            this.txb_jistyle = new System.Windows.Forms.TextBox();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_phone = new System.Windows.Forms.Label();
            this.txb_email = new System.Windows.Forms.TextBox();
            this.txb_dengji = new System.Windows.Forms.TextBox();
            this.txb_bedNo = new System.Windows.Forms.TextBox();
            this.but_bedcheck = new System.Windows.Forms.Button();
            this.txb_houseNo = new System.Windows.Forms.TextBox();
            this.txb_area = new System.Windows.Forms.TextBox();
            this.lb_dengji = new System.Windows.Forms.Label();
            this.lb_houseNo = new System.Windows.Forms.Label();
            this.lb_bedNo = new System.Windows.Forms.Label();
            this.lb_area = new System.Windows.Forms.Label();
            this.gb_sex = new System.Windows.Forms.GroupBox();
            this.gb_sex.SuspendLayout();
            this.SuspendLayout();
            // 
            // txb_keshi
            // 
            this.txb_keshi.Location = new System.Drawing.Point(111, 140);
            this.txb_keshi.Name = "txb_keshi";
            this.txb_keshi.Size = new System.Drawing.Size(145, 21);
            this.txb_keshi.TabIndex = 109;
            // 
            // but_chakan
            // 
            this.but_chakan.Location = new System.Drawing.Point(850, 96);
            this.but_chakan.Name = "but_chakan";
            this.but_chakan.Size = new System.Drawing.Size(75, 23);
            this.but_chakan.TabIndex = 108;
            this.but_chakan.Text = "查看 ";
            this.but_chakan.UseVisualStyleBackColor = true;
            this.but_chakan.Click += new System.EventHandler(this.but_chakan_Click);
            // 
            // txb_menzhenNo
            // 
            this.txb_menzhenNo.Location = new System.Drawing.Point(111, 46);
            this.txb_menzhenNo.Name = "txb_menzhenNo";
            this.txb_menzhenNo.Size = new System.Drawing.Size(100, 21);
            this.txb_menzhenNo.TabIndex = 107;
            // 
            // txb_menzhenday
            // 
            this.txb_menzhenday.Location = new System.Drawing.Point(316, 93);
            this.txb_menzhenday.Name = "txb_menzhenday";
            this.txb_menzhenday.Size = new System.Drawing.Size(100, 21);
            this.txb_menzhenday.TabIndex = 106;
            // 
            // lb_menzhenday
            // 
            this.lb_menzhenday.AutoSize = true;
            this.lb_menzhenday.BackColor = System.Drawing.Color.Transparent;
            this.lb_menzhenday.Location = new System.Drawing.Point(245, 96);
            this.lb_menzhenday.Name = "lb_menzhenday";
            this.lb_menzhenday.Size = new System.Drawing.Size(65, 12);
            this.lb_menzhenday.TabIndex = 105;
            this.lb_menzhenday.Text = "问诊日期：";
            // 
            // txb_zhenduandetail
            // 
            this.txb_zhenduandetail.Location = new System.Drawing.Point(111, 173);
            this.txb_zhenduandetail.Name = "txb_zhenduandetail";
            this.txb_zhenduandetail.Size = new System.Drawing.Size(628, 21);
            this.txb_zhenduandetail.TabIndex = 104;
            // 
            // txb_zhenduanma
            // 
            this.txb_zhenduanma.Location = new System.Drawing.Point(111, 93);
            this.txb_zhenduanma.Name = "txb_zhenduanma";
            this.txb_zhenduanma.Size = new System.Drawing.Size(100, 21);
            this.txb_zhenduanma.TabIndex = 103;
            // 
            // lb_menzhenNo
            // 
            this.lb_menzhenNo.AutoSize = true;
            this.lb_menzhenNo.BackColor = System.Drawing.Color.Transparent;
            this.lb_menzhenNo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lb_menzhenNo.Location = new System.Drawing.Point(52, 49);
            this.lb_menzhenNo.Name = "lb_menzhenNo";
            this.lb_menzhenNo.Size = new System.Drawing.Size(53, 12);
            this.lb_menzhenNo.TabIndex = 102;
            this.lb_menzhenNo.Text = "门诊号：";
            // 
            // lb_zhendangdetail
            // 
            this.lb_zhendangdetail.AutoSize = true;
            this.lb_zhendangdetail.BackColor = System.Drawing.Color.Transparent;
            this.lb_zhendangdetail.Location = new System.Drawing.Point(52, 176);
            this.lb_zhendangdetail.Name = "lb_zhendangdetail";
            this.lb_zhendangdetail.Size = new System.Drawing.Size(65, 12);
            this.lb_zhendangdetail.TabIndex = 101;
            this.lb_zhendangdetail.Text = "诊断说明：";
            // 
            // lb_zhenduanma
            // 
            this.lb_zhenduanma.AutoSize = true;
            this.lb_zhenduanma.BackColor = System.Drawing.Color.Transparent;
            this.lb_zhenduanma.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lb_zhenduanma.Location = new System.Drawing.Point(52, 96);
            this.lb_zhenduanma.Name = "lb_zhenduanma";
            this.lb_zhenduanma.Size = new System.Drawing.Size(65, 12);
            this.lb_zhenduanma.TabIndex = 100;
            this.lb_zhenduanma.Text = "诊断编码：";
            // 
            // lb_keshi
            // 
            this.lb_keshi.AutoSize = true;
            this.lb_keshi.BackColor = System.Drawing.Color.Transparent;
            this.lb_keshi.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lb_keshi.Location = new System.Drawing.Point(52, 143);
            this.lb_keshi.Name = "lb_keshi";
            this.lb_keshi.Size = new System.Drawing.Size(65, 12);
            this.lb_keshi.TabIndex = 99;
            this.lb_keshi.Text = "所属科室：";
            // 
            // dt_ruyuanday
            // 
            this.dt_ruyuanday.Location = new System.Drawing.Point(304, 258);
            this.dt_ruyuanday.Name = "dt_ruyuanday";
            this.dt_ruyuanday.Size = new System.Drawing.Size(200, 21);
            this.dt_ruyuanday.TabIndex = 148;
            // 
            // txb_ruyuantime
            // 
            this.txb_ruyuantime.Location = new System.Drawing.Point(602, 258);
            this.txb_ruyuantime.Name = "txb_ruyuantime";
            this.txb_ruyuantime.Size = new System.Drawing.Size(100, 21);
            this.txb_ruyuantime.TabIndex = 147;
            // 
            // lb_zuyuanNo
            // 
            this.lb_zuyuanNo.AutoSize = true;
            this.lb_zuyuanNo.BackColor = System.Drawing.Color.Transparent;
            this.lb_zuyuanNo.Location = new System.Drawing.Point(52, 261);
            this.lb_zuyuanNo.Name = "lb_zuyuanNo";
            this.lb_zuyuanNo.Size = new System.Drawing.Size(53, 12);
            this.lb_zuyuanNo.TabIndex = 110;
            this.lb_zuyuanNo.Text = "住院号：";
            // 
            // lb_relationname
            // 
            this.lb_relationname.AutoSize = true;
            this.lb_relationname.BackColor = System.Drawing.Color.Transparent;
            this.lb_relationname.Location = new System.Drawing.Point(466, 445);
            this.lb_relationname.Name = "lb_relationname";
            this.lb_relationname.Size = new System.Drawing.Size(65, 12);
            this.lb_relationname.TabIndex = 143;
            this.lb_relationname.Text = "联系姓名：";
            // 
            // dt_birthday
            // 
            this.dt_birthday.Location = new System.Drawing.Point(304, 348);
            this.dt_birthday.Name = "dt_birthday";
            this.dt_birthday.Size = new System.Drawing.Size(140, 21);
            this.dt_birthday.TabIndex = 146;
            // 
            // txb_relation
            // 
            this.txb_relation.Location = new System.Drawing.Point(719, 442);
            this.txb_relation.Name = "txb_relation";
            this.txb_relation.Size = new System.Drawing.Size(100, 21);
            this.txb_relation.TabIndex = 141;
            // 
            // lb_relation
            // 
            this.lb_relation.AutoSize = true;
            this.lb_relation.BackColor = System.Drawing.Color.Transparent;
            this.lb_relation.Location = new System.Drawing.Point(655, 445);
            this.lb_relation.Name = "lb_relation";
            this.lb_relation.Size = new System.Drawing.Size(65, 12);
            this.lb_relation.TabIndex = 142;
            this.lb_relation.Text = "联系关系：";
            // 
            // txb_zuyuanNo
            // 
            this.txb_zuyuanNo.Location = new System.Drawing.Point(111, 258);
            this.txb_zuyuanNo.Name = "txb_zuyuanNo";
            this.txb_zuyuanNo.Size = new System.Drawing.Size(100, 21);
            this.txb_zuyuanNo.TabIndex = 125;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(850, 378);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 134;
            this.button7.Text = "退院";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(850, 330);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 135;
            this.button8.Text = "回院";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(850, 294);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 136;
            this.button9.Text = "入院";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // rb_female
            // 
            this.rb_female.AutoSize = true;
            this.rb_female.Location = new System.Drawing.Point(77, 20);
            this.rb_female.Name = "rb_female";
            this.rb_female.Size = new System.Drawing.Size(35, 16);
            this.rb_female.TabIndex = 145;
            this.rb_female.TabStop = true;
            this.rb_female.Text = "女";
            this.rb_female.UseVisualStyleBackColor = true;
            // 
            // lb_ruyuanday
            // 
            this.lb_ruyuanday.AutoSize = true;
            this.lb_ruyuanday.BackColor = System.Drawing.Color.Transparent;
            this.lb_ruyuanday.Location = new System.Drawing.Point(233, 261);
            this.lb_ruyuanday.Name = "lb_ruyuanday";
            this.lb_ruyuanday.Size = new System.Drawing.Size(65, 12);
            this.lb_ruyuanday.TabIndex = 111;
            this.lb_ruyuanday.Text = "入院日期：";
            // 
            // rb_male
            // 
            this.rb_male.AutoSize = true;
            this.rb_male.Location = new System.Drawing.Point(19, 20);
            this.rb_male.Name = "rb_male";
            this.rb_male.Size = new System.Drawing.Size(35, 16);
            this.rb_male.TabIndex = 144;
            this.rb_male.TabStop = true;
            this.rb_male.Text = "男";
            this.rb_male.UseVisualStyleBackColor = true;
            // 
            // but_chaxun
            // 
            this.but_chaxun.Location = new System.Drawing.Point(850, 256);
            this.but_chaxun.Name = "but_chaxun";
            this.but_chaxun.Size = new System.Drawing.Size(75, 23);
            this.but_chaxun.TabIndex = 133;
            this.but_chaxun.Text = "查询";
            this.but_chaxun.UseVisualStyleBackColor = true;
            this.but_chaxun.Click += new System.EventHandler(this.but_chaxun_Click);
            // 
            // txb_country
            // 
            this.txb_country.Location = new System.Drawing.Point(719, 348);
            this.txb_country.Name = "txb_country";
            this.txb_country.Size = new System.Drawing.Size(100, 21);
            this.txb_country.TabIndex = 140;
            // 
            // lb_ruyuantime
            // 
            this.lb_ruyuantime.AutoSize = true;
            this.lb_ruyuantime.BackColor = System.Drawing.Color.Transparent;
            this.lb_ruyuantime.Location = new System.Drawing.Point(531, 261);
            this.lb_ruyuantime.Name = "lb_ruyuantime";
            this.lb_ruyuantime.Size = new System.Drawing.Size(65, 12);
            this.lb_ruyuantime.TabIndex = 112;
            this.lb_ruyuantime.Text = "入院时间：";
            // 
            // lb_country
            // 
            this.lb_country.AutoSize = true;
            this.lb_country.BackColor = System.Drawing.Color.Transparent;
            this.lb_country.Location = new System.Drawing.Point(655, 354);
            this.lb_country.Name = "lb_country";
            this.lb_country.Size = new System.Drawing.Size(41, 12);
            this.lb_country.TabIndex = 137;
            this.lb_country.Text = "国籍：";
            // 
            // txb_minzhu
            // 
            this.txb_minzhu.Location = new System.Drawing.Point(533, 348);
            this.txb_minzhu.Name = "txb_minzhu";
            this.txb_minzhu.Size = new System.Drawing.Size(100, 21);
            this.txb_minzhu.TabIndex = 139;
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.BackColor = System.Drawing.Color.Transparent;
            this.lb_name.Location = new System.Drawing.Point(52, 305);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(41, 12);
            this.lb_name.TabIndex = 113;
            this.lb_name.Text = "姓名：";
            // 
            // lb_minzhu
            // 
            this.lb_minzhu.AutoSize = true;
            this.lb_minzhu.BackColor = System.Drawing.Color.Transparent;
            this.lb_minzhu.Location = new System.Drawing.Point(466, 354);
            this.lb_minzhu.Name = "lb_minzhu";
            this.lb_minzhu.Size = new System.Drawing.Size(41, 12);
            this.lb_minzhu.TabIndex = 138;
            this.lb_minzhu.Text = "民族：";
            // 
            // txb_name
            // 
            this.txb_name.Location = new System.Drawing.Point(111, 302);
            this.txb_name.Name = "txb_name";
            this.txb_name.Size = new System.Drawing.Size(100, 21);
            this.txb_name.TabIndex = 126;
            // 
            // txb_relationname
            // 
            this.txb_relationname.Location = new System.Drawing.Point(533, 442);
            this.txb_relationname.Name = "txb_relationname";
            this.txb_relationname.Size = new System.Drawing.Size(100, 21);
            this.txb_relationname.TabIndex = 124;
            // 
            // txb_address
            // 
            this.txb_address.Location = new System.Drawing.Point(719, 400);
            this.txb_address.Name = "txb_address";
            this.txb_address.Size = new System.Drawing.Size(100, 21);
            this.txb_address.TabIndex = 132;
            // 
            // lb_idNo
            // 
            this.lb_idNo.AutoSize = true;
            this.lb_idNo.BackColor = System.Drawing.Color.Transparent;
            this.lb_idNo.Location = new System.Drawing.Point(233, 305);
            this.lb_idNo.Name = "lb_idNo";
            this.lb_idNo.Size = new System.Drawing.Size(65, 12);
            this.lb_idNo.TabIndex = 119;
            this.lb_idNo.Text = "身份证号：";
            // 
            // txb_phone
            // 
            this.txb_phone.Location = new System.Drawing.Point(533, 400);
            this.txb_phone.Name = "txb_phone";
            this.txb_phone.Size = new System.Drawing.Size(100, 21);
            this.txb_phone.TabIndex = 131;
            // 
            // txb_idNo
            // 
            this.txb_idNo.Location = new System.Drawing.Point(304, 302);
            this.txb_idNo.Name = "txb_idNo";
            this.txb_idNo.Size = new System.Drawing.Size(285, 21);
            this.txb_idNo.TabIndex = 130;
            // 
            // lb_marry
            // 
            this.lb_marry.AutoSize = true;
            this.lb_marry.BackColor = System.Drawing.Color.Transparent;
            this.lb_marry.Location = new System.Drawing.Point(52, 351);
            this.lb_marry.Name = "lb_marry";
            this.lb_marry.Size = new System.Drawing.Size(41, 12);
            this.lb_marry.TabIndex = 115;
            this.lb_marry.Text = "婚姻：";
            // 
            // txb_marry
            // 
            this.txb_marry.Location = new System.Drawing.Point(111, 348);
            this.txb_marry.Name = "txb_marry";
            this.txb_marry.Size = new System.Drawing.Size(100, 21);
            this.txb_marry.TabIndex = 127;
            // 
            // lb_job
            // 
            this.lb_job.AutoSize = true;
            this.lb_job.BackColor = System.Drawing.Color.Transparent;
            this.lb_job.Location = new System.Drawing.Point(52, 403);
            this.lb_job.Name = "lb_job";
            this.lb_job.Size = new System.Drawing.Size(41, 12);
            this.lb_job.TabIndex = 118;
            this.lb_job.Text = "职业：";
            // 
            // txb_job
            // 
            this.txb_job.Location = new System.Drawing.Point(111, 400);
            this.txb_job.Name = "txb_job";
            this.txb_job.Size = new System.Drawing.Size(100, 21);
            this.txb_job.TabIndex = 129;
            // 
            // lb_birthday
            // 
            this.lb_birthday.AutoSize = true;
            this.lb_birthday.BackColor = System.Drawing.Color.Transparent;
            this.lb_birthday.Location = new System.Drawing.Point(233, 351);
            this.lb_birthday.Name = "lb_birthday";
            this.lb_birthday.Size = new System.Drawing.Size(65, 12);
            this.lb_birthday.TabIndex = 116;
            this.lb_birthday.Text = "出生日期：";
            // 
            // lb_jistyle
            // 
            this.lb_jistyle.AutoSize = true;
            this.lb_jistyle.BackColor = System.Drawing.Color.Transparent;
            this.lb_jistyle.Location = new System.Drawing.Point(233, 403);
            this.lb_jistyle.Name = "lb_jistyle";
            this.lb_jistyle.Size = new System.Drawing.Size(65, 12);
            this.lb_jistyle.TabIndex = 117;
            this.lb_jistyle.Text = "记账类型：";
            // 
            // lb_address
            // 
            this.lb_address.AutoSize = true;
            this.lb_address.BackColor = System.Drawing.Color.Transparent;
            this.lb_address.Location = new System.Drawing.Point(655, 403);
            this.lb_address.Name = "lb_address";
            this.lb_address.Size = new System.Drawing.Size(65, 12);
            this.lb_address.TabIndex = 120;
            this.lb_address.Text = "联系地址：";
            // 
            // txb_jistyle
            // 
            this.txb_jistyle.Location = new System.Drawing.Point(304, 400);
            this.txb_jistyle.Name = "txb_jistyle";
            this.txb_jistyle.Size = new System.Drawing.Size(140, 21);
            this.txb_jistyle.TabIndex = 128;
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.BackColor = System.Drawing.Color.Transparent;
            this.lb_email.Location = new System.Drawing.Point(233, 445);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(65, 12);
            this.lb_email.TabIndex = 122;
            this.lb_email.Text = "地址邮编：";
            // 
            // lb_phone
            // 
            this.lb_phone.AutoSize = true;
            this.lb_phone.BackColor = System.Drawing.Color.Transparent;
            this.lb_phone.Location = new System.Drawing.Point(466, 403);
            this.lb_phone.Name = "lb_phone";
            this.lb_phone.Size = new System.Drawing.Size(65, 12);
            this.lb_phone.TabIndex = 121;
            this.lb_phone.Text = "联系电话：";
            // 
            // txb_email
            // 
            this.txb_email.Location = new System.Drawing.Point(304, 442);
            this.txb_email.Name = "txb_email";
            this.txb_email.Size = new System.Drawing.Size(140, 21);
            this.txb_email.TabIndex = 123;
            // 
            // txb_dengji
            // 
            this.txb_dengji.Location = new System.Drawing.Point(111, 574);
            this.txb_dengji.Name = "txb_dengji";
            this.txb_dengji.Size = new System.Drawing.Size(100, 21);
            this.txb_dengji.TabIndex = 154;
            // 
            // txb_bedNo
            // 
            this.txb_bedNo.Location = new System.Drawing.Point(533, 574);
            this.txb_bedNo.Name = "txb_bedNo";
            this.txb_bedNo.Size = new System.Drawing.Size(100, 21);
            this.txb_bedNo.TabIndex = 156;
            // 
            // but_bedcheck
            // 
            this.but_bedcheck.Location = new System.Drawing.Point(850, 547);
            this.but_bedcheck.Name = "but_bedcheck";
            this.but_bedcheck.Size = new System.Drawing.Size(75, 23);
            this.but_bedcheck.TabIndex = 157;
            this.but_bedcheck.Text = "查床位";
            this.but_bedcheck.UseVisualStyleBackColor = true;
            this.but_bedcheck.Click += new System.EventHandler(this.but_bedcheck_Click);
            // 
            // txb_houseNo
            // 
            this.txb_houseNo.Location = new System.Drawing.Point(304, 574);
            this.txb_houseNo.Name = "txb_houseNo";
            this.txb_houseNo.Size = new System.Drawing.Size(100, 21);
            this.txb_houseNo.TabIndex = 155;
            // 
            // txb_area
            // 
            this.txb_area.Location = new System.Drawing.Point(111, 527);
            this.txb_area.Name = "txb_area";
            this.txb_area.Size = new System.Drawing.Size(285, 21);
            this.txb_area.TabIndex = 153;
            // 
            // lb_dengji
            // 
            this.lb_dengji.AutoSize = true;
            this.lb_dengji.BackColor = System.Drawing.Color.Transparent;
            this.lb_dengji.Location = new System.Drawing.Point(52, 580);
            this.lb_dengji.Name = "lb_dengji";
            this.lb_dengji.Size = new System.Drawing.Size(65, 12);
            this.lb_dengji.TabIndex = 151;
            this.lb_dengji.Text = "床位等级：";
            // 
            // lb_houseNo
            // 
            this.lb_houseNo.AutoSize = true;
            this.lb_houseNo.BackColor = System.Drawing.Color.Transparent;
            this.lb_houseNo.Location = new System.Drawing.Point(233, 580);
            this.lb_houseNo.Name = "lb_houseNo";
            this.lb_houseNo.Size = new System.Drawing.Size(65, 12);
            this.lb_houseNo.TabIndex = 152;
            this.lb_houseNo.Text = "房间号码：";
            // 
            // lb_bedNo
            // 
            this.lb_bedNo.AutoSize = true;
            this.lb_bedNo.BackColor = System.Drawing.Color.Transparent;
            this.lb_bedNo.Location = new System.Drawing.Point(473, 580);
            this.lb_bedNo.Name = "lb_bedNo";
            this.lb_bedNo.Size = new System.Drawing.Size(53, 12);
            this.lb_bedNo.TabIndex = 150;
            this.lb_bedNo.Text = "床位号：";
            // 
            // lb_area
            // 
            this.lb_area.AutoSize = true;
            this.lb_area.BackColor = System.Drawing.Color.Transparent;
            this.lb_area.Location = new System.Drawing.Point(52, 530);
            this.lb_area.Name = "lb_area";
            this.lb_area.Size = new System.Drawing.Size(65, 12);
            this.lb_area.TabIndex = 149;
            this.lb_area.Text = "所属病区：";
            // 
            // gb_sex
            // 
            this.gb_sex.BackColor = System.Drawing.Color.Transparent;
            this.gb_sex.Controls.Add(this.rb_male);
            this.gb_sex.Controls.Add(this.rb_female);
            this.gb_sex.Location = new System.Drawing.Point(614, 294);
            this.gb_sex.Name = "gb_sex";
            this.gb_sex.Size = new System.Drawing.Size(125, 39);
            this.gb_sex.TabIndex = 158;
            this.gb_sex.TabStop = false;
            this.gb_sex.Text = "性别";
            // 
            // Frmruyuandengji
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(936, 621);
            this.Controls.Add(this.gb_sex);
            this.Controls.Add(this.txb_dengji);
            this.Controls.Add(this.txb_bedNo);
            this.Controls.Add(this.but_bedcheck);
            this.Controls.Add(this.txb_houseNo);
            this.Controls.Add(this.txb_area);
            this.Controls.Add(this.lb_dengji);
            this.Controls.Add(this.lb_houseNo);
            this.Controls.Add(this.lb_bedNo);
            this.Controls.Add(this.lb_area);
            this.Controls.Add(this.dt_ruyuanday);
            this.Controls.Add(this.txb_ruyuantime);
            this.Controls.Add(this.lb_zuyuanNo);
            this.Controls.Add(this.lb_relationname);
            this.Controls.Add(this.dt_birthday);
            this.Controls.Add(this.txb_relation);
            this.Controls.Add(this.lb_relation);
            this.Controls.Add(this.txb_zuyuanNo);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.lb_ruyuanday);
            this.Controls.Add(this.but_chaxun);
            this.Controls.Add(this.txb_country);
            this.Controls.Add(this.lb_ruyuantime);
            this.Controls.Add(this.lb_country);
            this.Controls.Add(this.txb_minzhu);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.lb_minzhu);
            this.Controls.Add(this.txb_name);
            this.Controls.Add(this.txb_relationname);
            this.Controls.Add(this.txb_address);
            this.Controls.Add(this.lb_idNo);
            this.Controls.Add(this.txb_phone);
            this.Controls.Add(this.txb_idNo);
            this.Controls.Add(this.lb_marry);
            this.Controls.Add(this.txb_marry);
            this.Controls.Add(this.lb_job);
            this.Controls.Add(this.txb_job);
            this.Controls.Add(this.lb_birthday);
            this.Controls.Add(this.lb_jistyle);
            this.Controls.Add(this.lb_address);
            this.Controls.Add(this.txb_jistyle);
            this.Controls.Add(this.lb_email);
            this.Controls.Add(this.lb_phone);
            this.Controls.Add(this.txb_email);
            this.Controls.Add(this.txb_keshi);
            this.Controls.Add(this.but_chakan);
            this.Controls.Add(this.txb_menzhenNo);
            this.Controls.Add(this.txb_menzhenday);
            this.Controls.Add(this.lb_menzhenday);
            this.Controls.Add(this.txb_zhenduandetail);
            this.Controls.Add(this.txb_zhenduanma);
            this.Controls.Add(this.lb_menzhenNo);
            this.Controls.Add(this.lb_zhendangdetail);
            this.Controls.Add(this.lb_zhenduanma);
            this.Controls.Add(this.lb_keshi);
            this.Name = "Frmruyuandengji";
            this.Text = "入院登记";
            this.gb_sex.ResumeLayout(false);
            this.gb_sex.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_keshi;
        private System.Windows.Forms.Button but_chakan;
        private System.Windows.Forms.TextBox txb_menzhenNo;
        private System.Windows.Forms.TextBox txb_menzhenday;
        private System.Windows.Forms.Label lb_menzhenday;
        private System.Windows.Forms.TextBox txb_zhenduandetail;
        private System.Windows.Forms.TextBox txb_zhenduanma;
        private System.Windows.Forms.Label lb_menzhenNo;
        private System.Windows.Forms.Label lb_zhendangdetail;
        private System.Windows.Forms.Label lb_zhenduanma;
        private System.Windows.Forms.Label lb_keshi;
        private System.Windows.Forms.DateTimePicker dt_ruyuanday;
        private System.Windows.Forms.TextBox txb_ruyuantime;
        private System.Windows.Forms.Label lb_zuyuanNo;
        private System.Windows.Forms.Label lb_relationname;
        private System.Windows.Forms.DateTimePicker dt_birthday;
        private System.Windows.Forms.TextBox txb_relation;
        private System.Windows.Forms.Label lb_relation;
        private System.Windows.Forms.TextBox txb_zuyuanNo;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.RadioButton rb_female;
        private System.Windows.Forms.Label lb_ruyuanday;
        private System.Windows.Forms.RadioButton rb_male;
        private System.Windows.Forms.Button but_chaxun;
        private System.Windows.Forms.TextBox txb_country;
        private System.Windows.Forms.Label lb_ruyuantime;
        private System.Windows.Forms.Label lb_country;
        private System.Windows.Forms.TextBox txb_minzhu;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_minzhu;
        private System.Windows.Forms.TextBox txb_name;
        private System.Windows.Forms.TextBox txb_relationname;
        private System.Windows.Forms.TextBox txb_address;
        private System.Windows.Forms.Label lb_idNo;
        private System.Windows.Forms.TextBox txb_phone;
        private System.Windows.Forms.TextBox txb_idNo;
        private System.Windows.Forms.Label lb_marry;
        private System.Windows.Forms.TextBox txb_marry;
        private System.Windows.Forms.Label lb_job;
        private System.Windows.Forms.TextBox txb_job;
        private System.Windows.Forms.Label lb_birthday;
        private System.Windows.Forms.Label lb_jistyle;
        private System.Windows.Forms.Label lb_address;
        private System.Windows.Forms.TextBox txb_jistyle;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.Label lb_phone;
        private System.Windows.Forms.TextBox txb_email;
        private System.Windows.Forms.TextBox txb_dengji;
        private System.Windows.Forms.TextBox txb_bedNo;
        private System.Windows.Forms.Button but_bedcheck;
        private System.Windows.Forms.TextBox txb_houseNo;
        private System.Windows.Forms.TextBox txb_area;
        private System.Windows.Forms.Label lb_dengji;
        private System.Windows.Forms.Label lb_houseNo;
        private System.Windows.Forms.Label lb_bedNo;
        private System.Windows.Forms.Label lb_area;
        private System.Windows.Forms.GroupBox gb_sex;
    }
}