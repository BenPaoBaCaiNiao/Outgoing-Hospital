﻿namespace 出入院系统
{
    partial class Frmjiezhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_zhuyuan = new System.Windows.Forms.Label();
            this.lb_gonghao = new System.Windows.Forms.Label();
            this.txt_chulixitong = new System.Windows.Forms.TextBox();
            this.dtb = new System.Windows.Forms.DateTimePicker();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.b_shuaxin = new System.Windows.Forms.Button();
            this.b_shuaka = new System.Windows.Forms.Button();
            this.b_chaxun = new System.Windows.Forms.Button();
            this.b_jisuan = new System.Windows.Forms.Button();
            this.b_mingxi = new System.Windows.Forms.Button();
            this.pb_zhixing = new System.Windows.Forms.PictureBox();
            this.pb_mingxi = new System.Windows.Forms.PictureBox();
            this.pb_jisuan = new System.Windows.Forms.PictureBox();
            this.pb_chaxun = new System.Windows.Forms.PictureBox();
            this.pb_shuaka = new System.Windows.Forms.PictureBox();
            this.pb_shuaxin = new System.Windows.Forms.PictureBox();
            this.b_zhixing = new System.Windows.Forms.Button();
            this.lb_menzhenhao = new System.Windows.Forms.Label();
            this.lb_xingming = new System.Windows.Forms.Label();
            this.lb_zhuyuanhao = new System.Windows.Forms.Label();
            this.lb_jizhangleixing = new System.Windows.Forms.Label();
            this.xingming = new System.Windows.Forms.Label();
            this.lb_ruyuanriqi = new System.Windows.Forms.Label();
            this.lb_suoshubingqu = new System.Windows.Forms.Label();
            this.lb_chuangweihao = new System.Windows.Forms.Label();
            this.lb_qishiriqi = new System.Windows.Forms.Label();
            this.lb_jiezhuruqi = new System.Windows.Forms.Label();
            this.lb_zongfeiyong = new System.Windows.Forms.Label();
            this.lb_weijiefeiyong = new System.Windows.Forms.Label();
            this.lb_baoxiaoxiaoji = new System.Windows.Forms.Label();
            this.lb_zifeixiaoji = new System.Windows.Forms.Label();
            this.lb_jizhangfeiyong = new System.Windows.Forms.Label();
            this.lb_gerenzhufu = new System.Windows.Forms.Label();
            this.lb_bencijiezhang = new System.Windows.Forms.Label();
            this.lb_zhuyuanzhuangtai = new System.Windows.Forms.Label();
            this.lb_chuyuanbaoliu = new System.Windows.Forms.Label();
            this.lb_gong = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lb_tian = new System.Windows.Forms.Label();
            this.lb_yinger = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cb_jiezhang = new System.Windows.Forms.CheckBox();
            this.lb_yishouzhipiao = new System.Windows.Forms.Label();
            this.lb_shoutuizhipiao = new System.Windows.Forms.Label();
            this.lb_yishouxianjin = new System.Windows.Forms.Label();
            this.lb_shoutuixianjin = new System.Windows.Forms.Label();
            this.cb_chuyuan = new System.Windows.Forms.CheckBox();
            this.cb_tuikuan = new System.Windows.Forms.CheckBox();
            this.txt_menzhenhao = new System.Windows.Forms.TextBox();
            this.txt_xingming = new System.Windows.Forms.TextBox();
            this.txt_xingbie = new System.Windows.Forms.TextBox();
            this.txt_suoshubingqi = new System.Windows.Forms.TextBox();
            this.txt_qishiriqi = new System.Windows.Forms.TextBox();
            this.txt_zongfeiyong = new System.Windows.Forms.TextBox();
            this.txt_baoxiaoxiaoji = new System.Windows.Forms.TextBox();
            this.txt_jizhangfeiyong = new System.Windows.Forms.TextBox();
            this.txt_bencijiezhang = new System.Windows.Forms.TextBox();
            this.txt_fapiaobianhao = new System.Windows.Forms.TextBox();
            this.txt_yishouzhipiao = new System.Windows.Forms.TextBox();
            this.txt_yishouxianjin = new System.Windows.Forms.TextBox();
            this.txt_chuyuanbaoliu = new System.Windows.Forms.TextBox();
            this.txt_gong = new System.Windows.Forms.TextBox();
            this.txt_zhuyuanhao = new System.Windows.Forms.TextBox();
            this.txt_jizhangleixing = new System.Windows.Forms.TextBox();
            this.txt_ruyuanriqi = new System.Windows.Forms.TextBox();
            this.txt_chuangweihao = new System.Windows.Forms.TextBox();
            this.txt_jiezhiriqi = new System.Windows.Forms.TextBox();
            this.txt_weijiefeiyong = new System.Windows.Forms.TextBox();
            this.txt_zifeixiaoji = new System.Windows.Forms.TextBox();
            this.txt_gerenzhifu = new System.Windows.Forms.TextBox();
            this.txt_zhuyuanzhuangtai = new System.Windows.Forms.TextBox();
            this.txt_yinger = new System.Windows.Forms.TextBox();
            this.txt_yinshuafapiao = new System.Windows.Forms.TextBox();
            this.txt_shoutuizhipiao = new System.Windows.Forms.TextBox();
            this.txt_shoutuixianjin = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_zhixing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mingxi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jisuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_chaxun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shuaka)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shuaxin)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_zhuyuan
            // 
            this.lb_zhuyuan.AutoSize = true;
            this.lb_zhuyuan.Location = new System.Drawing.Point(12, 9);
            this.lb_zhuyuan.Name = "lb_zhuyuan";
            this.lb_zhuyuan.Size = new System.Drawing.Size(29, 12);
            this.lb_zhuyuan.TabIndex = 1;
            this.lb_zhuyuan.Text = "住院";
            // 
            // lb_gonghao
            // 
            this.lb_gonghao.AutoSize = true;
            this.lb_gonghao.Location = new System.Drawing.Point(12, 30);
            this.lb_gonghao.Name = "lb_gonghao";
            this.lb_gonghao.Size = new System.Drawing.Size(41, 12);
            this.lb_gonghao.TabIndex = 2;
            this.lb_gonghao.Text = "工号：";
            // 
            // txt_chulixitong
            // 
            this.txt_chulixitong.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_chulixitong.Location = new System.Drawing.Point(305, 13);
            this.txt_chulixitong.Name = "txt_chulixitong";
            this.txt_chulixitong.Size = new System.Drawing.Size(146, 29);
            this.txt_chulixitong.TabIndex = 3;
            this.txt_chulixitong.Text = "出入院处理系统";
            // 
            // dtb
            // 
            this.dtb.Location = new System.Drawing.Point(594, 21);
            this.dtb.Name = "dtb";
            this.dtb.Size = new System.Drawing.Size(200, 21);
            this.dtb.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(12, 55);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(77, 256);
            this.listBox1.TabIndex = 6;
            // 
            // b_shuaxin
            // 
            this.b_shuaxin.Location = new System.Drawing.Point(332, 56);
            this.b_shuaxin.Name = "b_shuaxin";
            this.b_shuaxin.Size = new System.Drawing.Size(47, 23);
            this.b_shuaxin.TabIndex = 10;
            this.b_shuaxin.Text = "刷新";
            this.b_shuaxin.UseVisualStyleBackColor = true;
            // 
            // b_shuaka
            // 
            this.b_shuaka.Location = new System.Drawing.Point(417, 55);
            this.b_shuaka.Name = "b_shuaka";
            this.b_shuaka.Size = new System.Drawing.Size(41, 23);
            this.b_shuaka.TabIndex = 11;
            this.b_shuaka.Text = "刷卡";
            this.b_shuaka.UseVisualStyleBackColor = true;
            // 
            // b_chaxun
            // 
            this.b_chaxun.Location = new System.Drawing.Point(498, 57);
            this.b_chaxun.Name = "b_chaxun";
            this.b_chaxun.Size = new System.Drawing.Size(42, 23);
            this.b_chaxun.TabIndex = 13;
            this.b_chaxun.Text = "查询";
            this.b_chaxun.UseVisualStyleBackColor = true;
            // 
            // b_jisuan
            // 
            this.b_jisuan.Location = new System.Drawing.Point(581, 57);
            this.b_jisuan.Name = "b_jisuan";
            this.b_jisuan.Size = new System.Drawing.Size(42, 23);
            this.b_jisuan.TabIndex = 15;
            this.b_jisuan.Text = "计算";
            this.b_jisuan.UseVisualStyleBackColor = true;
            // 
            // b_mingxi
            // 
            this.b_mingxi.Location = new System.Drawing.Point(659, 59);
            this.b_mingxi.Name = "b_mingxi";
            this.b_mingxi.Size = new System.Drawing.Size(44, 23);
            this.b_mingxi.TabIndex = 17;
            this.b_mingxi.Text = "明细";
            this.b_mingxi.UseVisualStyleBackColor = true;
            // 
            // pb_zhixing
            // 
            this.pb_zhixing.Image = global::出入院系统.Properties.Resources.执行;
            this.pb_zhixing.Location = new System.Drawing.Point(709, 59);
            this.pb_zhixing.Name = "pb_zhixing";
            this.pb_zhixing.Size = new System.Drawing.Size(30, 24);
            this.pb_zhixing.TabIndex = 18;
            this.pb_zhixing.TabStop = false;
            // 
            // pb_mingxi
            // 
            this.pb_mingxi.Image = global::出入院系统.Properties.Resources.明细;
            this.pb_mingxi.Location = new System.Drawing.Point(629, 55);
            this.pb_mingxi.Name = "pb_mingxi";
            this.pb_mingxi.Size = new System.Drawing.Size(24, 29);
            this.pb_mingxi.TabIndex = 16;
            this.pb_mingxi.TabStop = false;
            // 
            // pb_jisuan
            // 
            this.pb_jisuan.Image = global::出入院系统.Properties.Resources.计算;
            this.pb_jisuan.Location = new System.Drawing.Point(546, 54);
            this.pb_jisuan.Name = "pb_jisuan";
            this.pb_jisuan.Size = new System.Drawing.Size(29, 27);
            this.pb_jisuan.TabIndex = 14;
            this.pb_jisuan.TabStop = false;
            // 
            // pb_chaxun
            // 
            this.pb_chaxun.Image = global::出入院系统.Properties.Resources.查询2;
            this.pb_chaxun.Location = new System.Drawing.Point(464, 54);
            this.pb_chaxun.Name = "pb_chaxun";
            this.pb_chaxun.Size = new System.Drawing.Size(28, 25);
            this.pb_chaxun.TabIndex = 12;
            this.pb_chaxun.TabStop = false;
            // 
            // pb_shuaka
            // 
            this.pb_shuaka.Image = global::出入院系统.Properties.Resources.刷卡2;
            this.pb_shuaka.Location = new System.Drawing.Point(385, 51);
            this.pb_shuaka.Name = "pb_shuaka";
            this.pb_shuaka.Size = new System.Drawing.Size(26, 29);
            this.pb_shuaka.TabIndex = 9;
            this.pb_shuaka.TabStop = false;
            // 
            // pb_shuaxin
            // 
            this.pb_shuaxin.Image = global::出入院系统.Properties.Resources.刷新;
            this.pb_shuaxin.Location = new System.Drawing.Point(305, 57);
            this.pb_shuaxin.Name = "pb_shuaxin";
            this.pb_shuaxin.Size = new System.Drawing.Size(21, 22);
            this.pb_shuaxin.TabIndex = 7;
            this.pb_shuaxin.TabStop = false;
            // 
            // b_zhixing
            // 
            this.b_zhixing.Location = new System.Drawing.Point(745, 60);
            this.b_zhixing.Name = "b_zhixing";
            this.b_zhixing.Size = new System.Drawing.Size(45, 23);
            this.b_zhixing.TabIndex = 19;
            this.b_zhixing.Text = "执行";
            this.b_zhixing.UseVisualStyleBackColor = true;
            // 
            // lb_menzhenhao
            // 
            this.lb_menzhenhao.AutoSize = true;
            this.lb_menzhenhao.Location = new System.Drawing.Point(95, 97);
            this.lb_menzhenhao.Name = "lb_menzhenhao";
            this.lb_menzhenhao.Size = new System.Drawing.Size(53, 12);
            this.lb_menzhenhao.TabIndex = 20;
            this.lb_menzhenhao.Text = "门 诊 号";
            // 
            // lb_xingming
            // 
            this.lb_xingming.AutoSize = true;
            this.lb_xingming.Location = new System.Drawing.Point(95, 123);
            this.lb_xingming.Name = "lb_xingming";
            this.lb_xingming.Size = new System.Drawing.Size(53, 12);
            this.lb_xingming.TabIndex = 21;
            this.lb_xingming.Text = "姓    名";
            // 
            // lb_zhuyuanhao
            // 
            this.lb_zhuyuanhao.AutoSize = true;
            this.lb_zhuyuanhao.Location = new System.Drawing.Point(242, 97);
            this.lb_zhuyuanhao.Name = "lb_zhuyuanhao";
            this.lb_zhuyuanhao.Size = new System.Drawing.Size(53, 12);
            this.lb_zhuyuanhao.TabIndex = 22;
            this.lb_zhuyuanhao.Text = "住 院 号";
            // 
            // lb_jizhangleixing
            // 
            this.lb_jizhangleixing.AutoSize = true;
            this.lb_jizhangleixing.Location = new System.Drawing.Point(242, 123);
            this.lb_jizhangleixing.Name = "lb_jizhangleixing";
            this.lb_jizhangleixing.Size = new System.Drawing.Size(53, 12);
            this.lb_jizhangleixing.TabIndex = 23;
            this.lb_jizhangleixing.Text = "记账类型";
            // 
            // xingming
            // 
            this.xingming.AutoSize = true;
            this.xingming.Location = new System.Drawing.Point(95, 154);
            this.xingming.Name = "xingming";
            this.xingming.Size = new System.Drawing.Size(53, 12);
            this.xingming.TabIndex = 24;
            this.xingming.Text = "性    别";
            // 
            // lb_ruyuanriqi
            // 
            this.lb_ruyuanriqi.AutoSize = true;
            this.lb_ruyuanriqi.Location = new System.Drawing.Point(242, 154);
            this.lb_ruyuanriqi.Name = "lb_ruyuanriqi";
            this.lb_ruyuanriqi.Size = new System.Drawing.Size(53, 12);
            this.lb_ruyuanriqi.TabIndex = 25;
            this.lb_ruyuanriqi.Text = "入院日期";
            // 
            // lb_suoshubingqu
            // 
            this.lb_suoshubingqu.AutoSize = true;
            this.lb_suoshubingqu.Location = new System.Drawing.Point(95, 180);
            this.lb_suoshubingqu.Name = "lb_suoshubingqu";
            this.lb_suoshubingqu.Size = new System.Drawing.Size(53, 12);
            this.lb_suoshubingqu.TabIndex = 26;
            this.lb_suoshubingqu.Text = "所属病区";
            // 
            // lb_chuangweihao
            // 
            this.lb_chuangweihao.AutoSize = true;
            this.lb_chuangweihao.Location = new System.Drawing.Point(244, 180);
            this.lb_chuangweihao.Name = "lb_chuangweihao";
            this.lb_chuangweihao.Size = new System.Drawing.Size(53, 12);
            this.lb_chuangweihao.TabIndex = 27;
            this.lb_chuangweihao.Text = "床 位 号";
            // 
            // lb_qishiriqi
            // 
            this.lb_qishiriqi.AutoSize = true;
            this.lb_qishiriqi.Location = new System.Drawing.Point(95, 210);
            this.lb_qishiriqi.Name = "lb_qishiriqi";
            this.lb_qishiriqi.Size = new System.Drawing.Size(53, 12);
            this.lb_qishiriqi.TabIndex = 28;
            this.lb_qishiriqi.Text = "起始日期";
            // 
            // lb_jiezhuruqi
            // 
            this.lb_jiezhuruqi.AutoSize = true;
            this.lb_jiezhuruqi.Location = new System.Drawing.Point(244, 210);
            this.lb_jiezhuruqi.Name = "lb_jiezhuruqi";
            this.lb_jiezhuruqi.Size = new System.Drawing.Size(53, 12);
            this.lb_jiezhuruqi.TabIndex = 29;
            this.lb_jiezhuruqi.Text = "截止日期";
            // 
            // lb_zongfeiyong
            // 
            this.lb_zongfeiyong.AutoSize = true;
            this.lb_zongfeiyong.Location = new System.Drawing.Point(97, 242);
            this.lb_zongfeiyong.Name = "lb_zongfeiyong";
            this.lb_zongfeiyong.Size = new System.Drawing.Size(53, 12);
            this.lb_zongfeiyong.TabIndex = 30;
            this.lb_zongfeiyong.Text = "总 费 用";
            // 
            // lb_weijiefeiyong
            // 
            this.lb_weijiefeiyong.AutoSize = true;
            this.lb_weijiefeiyong.Location = new System.Drawing.Point(244, 242);
            this.lb_weijiefeiyong.Name = "lb_weijiefeiyong";
            this.lb_weijiefeiyong.Size = new System.Drawing.Size(53, 12);
            this.lb_weijiefeiyong.TabIndex = 31;
            this.lb_weijiefeiyong.Text = "未结费用";
            // 
            // lb_baoxiaoxiaoji
            // 
            this.lb_baoxiaoxiaoji.AutoSize = true;
            this.lb_baoxiaoxiaoji.Location = new System.Drawing.Point(97, 271);
            this.lb_baoxiaoxiaoji.Name = "lb_baoxiaoxiaoji";
            this.lb_baoxiaoxiaoji.Size = new System.Drawing.Size(53, 12);
            this.lb_baoxiaoxiaoji.TabIndex = 32;
            this.lb_baoxiaoxiaoji.Text = "报销小计";
            // 
            // lb_zifeixiaoji
            // 
            this.lb_zifeixiaoji.AutoSize = true;
            this.lb_zifeixiaoji.Location = new System.Drawing.Point(242, 271);
            this.lb_zifeixiaoji.Name = "lb_zifeixiaoji";
            this.lb_zifeixiaoji.Size = new System.Drawing.Size(53, 12);
            this.lb_zifeixiaoji.TabIndex = 33;
            this.lb_zifeixiaoji.Text = "自费小计";
            // 
            // lb_jizhangfeiyong
            // 
            this.lb_jizhangfeiyong.AutoSize = true;
            this.lb_jizhangfeiyong.Location = new System.Drawing.Point(97, 298);
            this.lb_jizhangfeiyong.Name = "lb_jizhangfeiyong";
            this.lb_jizhangfeiyong.Size = new System.Drawing.Size(53, 12);
            this.lb_jizhangfeiyong.TabIndex = 34;
            this.lb_jizhangfeiyong.Text = "记账费用";
            // 
            // lb_gerenzhufu
            // 
            this.lb_gerenzhufu.AutoSize = true;
            this.lb_gerenzhufu.Location = new System.Drawing.Point(244, 297);
            this.lb_gerenzhufu.Name = "lb_gerenzhufu";
            this.lb_gerenzhufu.Size = new System.Drawing.Size(53, 12);
            this.lb_gerenzhufu.TabIndex = 35;
            this.lb_gerenzhufu.Text = "个人支付";
            // 
            // lb_bencijiezhang
            // 
            this.lb_bencijiezhang.AutoSize = true;
            this.lb_bencijiezhang.Location = new System.Drawing.Point(97, 322);
            this.lb_bencijiezhang.Name = "lb_bencijiezhang";
            this.lb_bencijiezhang.Size = new System.Drawing.Size(53, 12);
            this.lb_bencijiezhang.TabIndex = 36;
            this.lb_bencijiezhang.Text = "本次结账";
            // 
            // lb_zhuyuanzhuangtai
            // 
            this.lb_zhuyuanzhuangtai.AutoSize = true;
            this.lb_zhuyuanzhuangtai.Location = new System.Drawing.Point(244, 322);
            this.lb_zhuyuanzhuangtai.Name = "lb_zhuyuanzhuangtai";
            this.lb_zhuyuanzhuangtai.Size = new System.Drawing.Size(53, 12);
            this.lb_zhuyuanzhuangtai.TabIndex = 37;
            this.lb_zhuyuanzhuangtai.Text = "住院状态";
            // 
            // lb_chuyuanbaoliu
            // 
            this.lb_chuyuanbaoliu.AutoSize = true;
            this.lb_chuyuanbaoliu.Location = new System.Drawing.Point(97, 344);
            this.lb_chuyuanbaoliu.Name = "lb_chuyuanbaoliu";
            this.lb_chuyuanbaoliu.Size = new System.Drawing.Size(53, 12);
            this.lb_chuyuanbaoliu.TabIndex = 38;
            this.lb_chuyuanbaoliu.Text = "出院保留";
            // 
            // lb_gong
            // 
            this.lb_gong.AutoSize = true;
            this.lb_gong.Location = new System.Drawing.Point(188, 347);
            this.lb_gong.Name = "lb_gong";
            this.lb_gong.Size = new System.Drawing.Size(41, 12);
            this.lb_gong.TabIndex = 39;
            this.lb_gong.Text = "天，共";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(97, 373);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 40;
            this.label23.Text = "发票编号";
            // 
            // lb_tian
            // 
            this.lb_tian.AutoSize = true;
            this.lb_tian.Location = new System.Drawing.Point(280, 347);
            this.lb_tian.Name = "lb_tian";
            this.lb_tian.Size = new System.Drawing.Size(17, 12);
            this.lb_tian.TabIndex = 41;
            this.lb_tian.Text = "天";
            this.lb_tian.Click += new System.EventHandler(this.label24_Click);
            // 
            // lb_yinger
            // 
            this.lb_yinger.AutoSize = true;
            this.lb_yinger.Location = new System.Drawing.Point(313, 347);
            this.lb_yinger.Name = "lb_yinger";
            this.lb_yinger.Size = new System.Drawing.Size(29, 12);
            this.lb_yinger.TabIndex = 42;
            this.lb_yinger.Text = "婴儿";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(244, 374);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 43;
            this.label26.Text = "印刷发票";
            // 
            // cb_jiezhang
            // 
            this.cb_jiezhang.AutoSize = true;
            this.cb_jiezhang.Location = new System.Drawing.Point(117, 395);
            this.cb_jiezhang.Name = "cb_jiezhang";
            this.cb_jiezhang.Size = new System.Drawing.Size(78, 16);
            this.cb_jiezhang.TabIndex = 44;
            this.cb_jiezhang.Text = "结账（J）";
            this.cb_jiezhang.UseVisualStyleBackColor = true;
            // 
            // lb_yishouzhipiao
            // 
            this.lb_yishouzhipiao.AutoSize = true;
            this.lb_yishouzhipiao.Location = new System.Drawing.Point(97, 423);
            this.lb_yishouzhipiao.Name = "lb_yishouzhipiao";
            this.lb_yishouzhipiao.Size = new System.Drawing.Size(53, 12);
            this.lb_yishouzhipiao.TabIndex = 45;
            this.lb_yishouzhipiao.Text = "已收支票";
            // 
            // lb_shoutuizhipiao
            // 
            this.lb_shoutuizhipiao.AutoSize = true;
            this.lb_shoutuizhipiao.Location = new System.Drawing.Point(248, 423);
            this.lb_shoutuizhipiao.Name = "lb_shoutuizhipiao";
            this.lb_shoutuizhipiao.Size = new System.Drawing.Size(59, 12);
            this.lb_shoutuizhipiao.TabIndex = 46;
            this.lb_shoutuizhipiao.Text = "收/退支票";
            // 
            // lb_yishouxianjin
            // 
            this.lb_yishouxianjin.AutoSize = true;
            this.lb_yishouxianjin.Location = new System.Drawing.Point(97, 450);
            this.lb_yishouxianjin.Name = "lb_yishouxianjin";
            this.lb_yishouxianjin.Size = new System.Drawing.Size(53, 12);
            this.lb_yishouxianjin.TabIndex = 47;
            this.lb_yishouxianjin.Text = "已收现金";
            // 
            // lb_shoutuixianjin
            // 
            this.lb_shoutuixianjin.AutoSize = true;
            this.lb_shoutuixianjin.Location = new System.Drawing.Point(248, 450);
            this.lb_shoutuixianjin.Name = "lb_shoutuixianjin";
            this.lb_shoutuixianjin.Size = new System.Drawing.Size(59, 12);
            this.lb_shoutuixianjin.TabIndex = 48;
            this.lb_shoutuixianjin.Text = "收/退现金";
            // 
            // cb_chuyuan
            // 
            this.cb_chuyuan.AutoSize = true;
            this.cb_chuyuan.Location = new System.Drawing.Point(190, 395);
            this.cb_chuyuan.Name = "cb_chuyuan";
            this.cb_chuyuan.Size = new System.Drawing.Size(78, 16);
            this.cb_chuyuan.TabIndex = 49;
            this.cb_chuyuan.Text = "出院（C）";
            this.cb_chuyuan.UseVisualStyleBackColor = true;
            // 
            // cb_tuikuan
            // 
            this.cb_tuikuan.AutoSize = true;
            this.cb_tuikuan.Location = new System.Drawing.Point(264, 395);
            this.cb_tuikuan.Name = "cb_tuikuan";
            this.cb_tuikuan.Size = new System.Drawing.Size(78, 16);
            this.cb_tuikuan.TabIndex = 50;
            this.cb_tuikuan.Text = "退款（T）";
            this.cb_tuikuan.UseVisualStyleBackColor = true;
            // 
            // txt_menzhenhao
            // 
            this.txt_menzhenhao.Location = new System.Drawing.Point(155, 94);
            this.txt_menzhenhao.Name = "txt_menzhenhao";
            this.txt_menzhenhao.Size = new System.Drawing.Size(81, 21);
            this.txt_menzhenhao.TabIndex = 51;
            // 
            // txt_xingming
            // 
            this.txt_xingming.Location = new System.Drawing.Point(155, 120);
            this.txt_xingming.Name = "txt_xingming";
            this.txt_xingming.Size = new System.Drawing.Size(81, 21);
            this.txt_xingming.TabIndex = 52;
            // 
            // txt_xingbie
            // 
            this.txt_xingbie.Location = new System.Drawing.Point(155, 147);
            this.txt_xingbie.Name = "txt_xingbie";
            this.txt_xingbie.Size = new System.Drawing.Size(81, 21);
            this.txt_xingbie.TabIndex = 53;
            // 
            // txt_suoshubingqi
            // 
            this.txt_suoshubingqi.Location = new System.Drawing.Point(155, 174);
            this.txt_suoshubingqi.Name = "txt_suoshubingqi";
            this.txt_suoshubingqi.Size = new System.Drawing.Size(81, 21);
            this.txt_suoshubingqi.TabIndex = 54;
            // 
            // txt_qishiriqi
            // 
            this.txt_qishiriqi.Location = new System.Drawing.Point(155, 207);
            this.txt_qishiriqi.Name = "txt_qishiriqi";
            this.txt_qishiriqi.Size = new System.Drawing.Size(81, 21);
            this.txt_qishiriqi.TabIndex = 55;
            this.txt_qishiriqi.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txt_zongfeiyong
            // 
            this.txt_zongfeiyong.Location = new System.Drawing.Point(155, 234);
            this.txt_zongfeiyong.Name = "txt_zongfeiyong";
            this.txt_zongfeiyong.Size = new System.Drawing.Size(81, 21);
            this.txt_zongfeiyong.TabIndex = 56;
            // 
            // txt_baoxiaoxiaoji
            // 
            this.txt_baoxiaoxiaoji.Location = new System.Drawing.Point(155, 266);
            this.txt_baoxiaoxiaoji.Name = "txt_baoxiaoxiaoji";
            this.txt_baoxiaoxiaoji.Size = new System.Drawing.Size(81, 21);
            this.txt_baoxiaoxiaoji.TabIndex = 57;
            // 
            // txt_jizhangfeiyong
            // 
            this.txt_jizhangfeiyong.Location = new System.Drawing.Point(155, 293);
            this.txt_jizhangfeiyong.Name = "txt_jizhangfeiyong";
            this.txt_jizhangfeiyong.Size = new System.Drawing.Size(81, 21);
            this.txt_jizhangfeiyong.TabIndex = 58;
            // 
            // txt_bencijiezhang
            // 
            this.txt_bencijiezhang.Location = new System.Drawing.Point(155, 320);
            this.txt_bencijiezhang.Name = "txt_bencijiezhang";
            this.txt_bencijiezhang.Size = new System.Drawing.Size(81, 21);
            this.txt_bencijiezhang.TabIndex = 59;
            this.txt_bencijiezhang.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // txt_fapiaobianhao
            // 
            this.txt_fapiaobianhao.Location = new System.Drawing.Point(153, 368);
            this.txt_fapiaobianhao.Name = "txt_fapiaobianhao";
            this.txt_fapiaobianhao.Size = new System.Drawing.Size(81, 21);
            this.txt_fapiaobianhao.TabIndex = 60;
            // 
            // txt_yishouzhipiao
            // 
            this.txt_yishouzhipiao.Location = new System.Drawing.Point(155, 420);
            this.txt_yishouzhipiao.Name = "txt_yishouzhipiao";
            this.txt_yishouzhipiao.Size = new System.Drawing.Size(81, 21);
            this.txt_yishouzhipiao.TabIndex = 61;
            // 
            // txt_yishouxianjin
            // 
            this.txt_yishouxianjin.Location = new System.Drawing.Point(155, 447);
            this.txt_yishouxianjin.Name = "txt_yishouxianjin";
            this.txt_yishouxianjin.Size = new System.Drawing.Size(81, 21);
            this.txt_yishouxianjin.TabIndex = 62;
            // 
            // txt_chuyuanbaoliu
            // 
            this.txt_chuyuanbaoliu.Location = new System.Drawing.Point(153, 344);
            this.txt_chuyuanbaoliu.Name = "txt_chuyuanbaoliu";
            this.txt_chuyuanbaoliu.Size = new System.Drawing.Size(29, 21);
            this.txt_chuyuanbaoliu.TabIndex = 63;
            // 
            // txt_gong
            // 
            this.txt_gong.Location = new System.Drawing.Point(235, 341);
            this.txt_gong.Name = "txt_gong";
            this.txt_gong.Size = new System.Drawing.Size(39, 21);
            this.txt_gong.TabIndex = 64;
            // 
            // txt_zhuyuanhao
            // 
            this.txt_zhuyuanhao.Location = new System.Drawing.Point(301, 94);
            this.txt_zhuyuanhao.Name = "txt_zhuyuanhao";
            this.txt_zhuyuanhao.Size = new System.Drawing.Size(81, 21);
            this.txt_zhuyuanhao.TabIndex = 65;
            // 
            // txt_jizhangleixing
            // 
            this.txt_jizhangleixing.Location = new System.Drawing.Point(301, 121);
            this.txt_jizhangleixing.Name = "txt_jizhangleixing";
            this.txt_jizhangleixing.Size = new System.Drawing.Size(81, 21);
            this.txt_jizhangleixing.TabIndex = 66;
            // 
            // txt_ruyuanriqi
            // 
            this.txt_ruyuanriqi.Location = new System.Drawing.Point(301, 151);
            this.txt_ruyuanriqi.Name = "txt_ruyuanriqi";
            this.txt_ruyuanriqi.Size = new System.Drawing.Size(81, 21);
            this.txt_ruyuanriqi.TabIndex = 67;
            // 
            // txt_chuangweihao
            // 
            this.txt_chuangweihao.Location = new System.Drawing.Point(301, 177);
            this.txt_chuangweihao.Name = "txt_chuangweihao";
            this.txt_chuangweihao.Size = new System.Drawing.Size(81, 21);
            this.txt_chuangweihao.TabIndex = 68;
            // 
            // txt_jiezhiriqi
            // 
            this.txt_jiezhiriqi.Location = new System.Drawing.Point(301, 207);
            this.txt_jiezhiriqi.Name = "txt_jiezhiriqi";
            this.txt_jiezhiriqi.Size = new System.Drawing.Size(81, 21);
            this.txt_jiezhiriqi.TabIndex = 69;
            // 
            // txt_weijiefeiyong
            // 
            this.txt_weijiefeiyong.Location = new System.Drawing.Point(301, 234);
            this.txt_weijiefeiyong.Name = "txt_weijiefeiyong";
            this.txt_weijiefeiyong.Size = new System.Drawing.Size(81, 21);
            this.txt_weijiefeiyong.TabIndex = 70;
            // 
            // txt_zifeixiaoji
            // 
            this.txt_zifeixiaoji.Location = new System.Drawing.Point(301, 268);
            this.txt_zifeixiaoji.Name = "txt_zifeixiaoji";
            this.txt_zifeixiaoji.Size = new System.Drawing.Size(81, 21);
            this.txt_zifeixiaoji.TabIndex = 71;
            // 
            // txt_gerenzhifu
            // 
            this.txt_gerenzhifu.Location = new System.Drawing.Point(301, 295);
            this.txt_gerenzhifu.Name = "txt_gerenzhifu";
            this.txt_gerenzhifu.Size = new System.Drawing.Size(81, 21);
            this.txt_gerenzhifu.TabIndex = 72;
            // 
            // txt_zhuyuanzhuangtai
            // 
            this.txt_zhuyuanzhuangtai.Location = new System.Drawing.Point(301, 319);
            this.txt_zhuyuanzhuangtai.Name = "txt_zhuyuanzhuangtai";
            this.txt_zhuyuanzhuangtai.Size = new System.Drawing.Size(81, 21);
            this.txt_zhuyuanzhuangtai.TabIndex = 73;
            // 
            // txt_yinger
            // 
            this.txt_yinger.Location = new System.Drawing.Point(348, 344);
            this.txt_yinger.Name = "txt_yinger";
            this.txt_yinger.Size = new System.Drawing.Size(34, 21);
            this.txt_yinger.TabIndex = 74;
            // 
            // txt_yinshuafapiao
            // 
            this.txt_yinshuafapiao.Location = new System.Drawing.Point(301, 368);
            this.txt_yinshuafapiao.Name = "txt_yinshuafapiao";
            this.txt_yinshuafapiao.Size = new System.Drawing.Size(81, 21);
            this.txt_yinshuafapiao.TabIndex = 75;
            // 
            // txt_shoutuizhipiao
            // 
            this.txt_shoutuizhipiao.Location = new System.Drawing.Point(313, 420);
            this.txt_shoutuizhipiao.Name = "txt_shoutuizhipiao";
            this.txt_shoutuizhipiao.Size = new System.Drawing.Size(81, 21);
            this.txt_shoutuizhipiao.TabIndex = 76;
            // 
            // txt_shoutuixianjin
            // 
            this.txt_shoutuixianjin.Location = new System.Drawing.Point(313, 447);
            this.txt_shoutuixianjin.Name = "txt_shoutuixianjin";
            this.txt_shoutuixianjin.Size = new System.Drawing.Size(81, 21);
            this.txt_shoutuixianjin.TabIndex = 77;
            // 
            // 出院结账处理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 549);
            this.Controls.Add(this.txt_shoutuixianjin);
            this.Controls.Add(this.txt_shoutuizhipiao);
            this.Controls.Add(this.txt_yinshuafapiao);
            this.Controls.Add(this.txt_yinger);
            this.Controls.Add(this.txt_zhuyuanzhuangtai);
            this.Controls.Add(this.txt_gerenzhifu);
            this.Controls.Add(this.txt_zifeixiaoji);
            this.Controls.Add(this.txt_weijiefeiyong);
            this.Controls.Add(this.txt_jiezhiriqi);
            this.Controls.Add(this.txt_chuangweihao);
            this.Controls.Add(this.txt_ruyuanriqi);
            this.Controls.Add(this.txt_jizhangleixing);
            this.Controls.Add(this.txt_zhuyuanhao);
            this.Controls.Add(this.txt_gong);
            this.Controls.Add(this.txt_chuyuanbaoliu);
            this.Controls.Add(this.txt_yishouxianjin);
            this.Controls.Add(this.txt_yishouzhipiao);
            this.Controls.Add(this.txt_fapiaobianhao);
            this.Controls.Add(this.txt_bencijiezhang);
            this.Controls.Add(this.txt_jizhangfeiyong);
            this.Controls.Add(this.txt_baoxiaoxiaoji);
            this.Controls.Add(this.txt_zongfeiyong);
            this.Controls.Add(this.txt_qishiriqi);
            this.Controls.Add(this.txt_suoshubingqi);
            this.Controls.Add(this.txt_xingbie);
            this.Controls.Add(this.txt_xingming);
            this.Controls.Add(this.txt_menzhenhao);
            this.Controls.Add(this.cb_tuikuan);
            this.Controls.Add(this.cb_chuyuan);
            this.Controls.Add(this.lb_shoutuixianjin);
            this.Controls.Add(this.lb_yishouxianjin);
            this.Controls.Add(this.lb_shoutuizhipiao);
            this.Controls.Add(this.lb_yishouzhipiao);
            this.Controls.Add(this.cb_jiezhang);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.lb_yinger);
            this.Controls.Add(this.lb_tian);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.lb_gong);
            this.Controls.Add(this.lb_chuyuanbaoliu);
            this.Controls.Add(this.lb_zhuyuanzhuangtai);
            this.Controls.Add(this.lb_bencijiezhang);
            this.Controls.Add(this.lb_gerenzhufu);
            this.Controls.Add(this.lb_jizhangfeiyong);
            this.Controls.Add(this.lb_zifeixiaoji);
            this.Controls.Add(this.lb_baoxiaoxiaoji);
            this.Controls.Add(this.lb_weijiefeiyong);
            this.Controls.Add(this.lb_zongfeiyong);
            this.Controls.Add(this.lb_jiezhuruqi);
            this.Controls.Add(this.lb_qishiriqi);
            this.Controls.Add(this.lb_chuangweihao);
            this.Controls.Add(this.lb_suoshubingqu);
            this.Controls.Add(this.lb_ruyuanriqi);
            this.Controls.Add(this.xingming);
            this.Controls.Add(this.lb_jizhangleixing);
            this.Controls.Add(this.lb_zhuyuanhao);
            this.Controls.Add(this.lb_xingming);
            this.Controls.Add(this.lb_menzhenhao);
            this.Controls.Add(this.b_zhixing);
            this.Controls.Add(this.pb_zhixing);
            this.Controls.Add(this.b_mingxi);
            this.Controls.Add(this.pb_mingxi);
            this.Controls.Add(this.b_jisuan);
            this.Controls.Add(this.pb_jisuan);
            this.Controls.Add(this.b_chaxun);
            this.Controls.Add(this.pb_chaxun);
            this.Controls.Add(this.b_shuaka);
            this.Controls.Add(this.b_shuaxin);
            this.Controls.Add(this.pb_shuaka);
            this.Controls.Add(this.pb_shuaxin);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.dtb);
            this.Controls.Add(this.txt_chulixitong);
            this.Controls.Add(this.lb_gonghao);
            this.Controls.Add(this.lb_zhuyuan);
            this.Name = "出院结账处理";
            this.Text = "出院结账处理";
            ((System.ComponentModel.ISupportInitialize)(this.pb_zhixing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_mingxi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_jisuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_chaxun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shuaka)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shuaxin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_zhuyuan;
        private System.Windows.Forms.Label lb_gonghao;
        private System.Windows.Forms.TextBox txt_chulixitong;
        private System.Windows.Forms.DateTimePicker dtb;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.PictureBox pb_shuaxin;
        private System.Windows.Forms.PictureBox pb_shuaka;
        private System.Windows.Forms.Button b_shuaxin;
        private System.Windows.Forms.Button b_shuaka;
        private System.Windows.Forms.PictureBox pb_chaxun;
        private System.Windows.Forms.Button b_chaxun;
        private System.Windows.Forms.PictureBox pb_jisuan;
        private System.Windows.Forms.Button b_jisuan;
        private System.Windows.Forms.PictureBox pb_mingxi;
        private System.Windows.Forms.Button b_mingxi;
        private System.Windows.Forms.PictureBox pb_zhixing;
        private System.Windows.Forms.Button b_zhixing;
        private System.Windows.Forms.Label lb_menzhenhao;
        private System.Windows.Forms.Label lb_xingming;
        private System.Windows.Forms.Label lb_zhuyuanhao;
        private System.Windows.Forms.Label lb_jizhangleixing;
        private System.Windows.Forms.Label xingming;
        private System.Windows.Forms.Label lb_ruyuanriqi;
        private System.Windows.Forms.Label lb_suoshubingqu;
        private System.Windows.Forms.Label lb_chuangweihao;
        private System.Windows.Forms.Label lb_qishiriqi;
        private System.Windows.Forms.Label lb_jiezhuruqi;
        private System.Windows.Forms.Label lb_zongfeiyong;
        private System.Windows.Forms.Label lb_weijiefeiyong;
        private System.Windows.Forms.Label lb_baoxiaoxiaoji;
        private System.Windows.Forms.Label lb_zifeixiaoji;
        private System.Windows.Forms.Label lb_jizhangfeiyong;
        private System.Windows.Forms.Label lb_gerenzhufu;
        private System.Windows.Forms.Label lb_bencijiezhang;
        private System.Windows.Forms.Label lb_zhuyuanzhuangtai;
        private System.Windows.Forms.Label lb_chuyuanbaoliu;
        private System.Windows.Forms.Label lb_gong;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lb_tian;
        private System.Windows.Forms.Label lb_yinger;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox cb_jiezhang;
        private System.Windows.Forms.Label lb_yishouzhipiao;
        private System.Windows.Forms.Label lb_shoutuizhipiao;
        private System.Windows.Forms.Label lb_yishouxianjin;
        private System.Windows.Forms.Label lb_shoutuixianjin;
        private System.Windows.Forms.CheckBox cb_chuyuan;
        private System.Windows.Forms.CheckBox cb_tuikuan;
        private System.Windows.Forms.TextBox txt_menzhenhao;
        private System.Windows.Forms.TextBox txt_xingming;
        private System.Windows.Forms.TextBox txt_xingbie;
        private System.Windows.Forms.TextBox txt_suoshubingqi;
        private System.Windows.Forms.TextBox txt_qishiriqi;
        private System.Windows.Forms.TextBox txt_zongfeiyong;
        private System.Windows.Forms.TextBox txt_baoxiaoxiaoji;
        private System.Windows.Forms.TextBox txt_jizhangfeiyong;
        private System.Windows.Forms.TextBox txt_bencijiezhang;
        private System.Windows.Forms.TextBox txt_fapiaobianhao;
        private System.Windows.Forms.TextBox txt_yishouzhipiao;
        private System.Windows.Forms.TextBox txt_yishouxianjin;
        private System.Windows.Forms.TextBox txt_chuyuanbaoliu;
        private System.Windows.Forms.TextBox txt_gong;
        private System.Windows.Forms.TextBox txt_zhuyuanhao;
        private System.Windows.Forms.TextBox txt_jizhangleixing;
        private System.Windows.Forms.TextBox txt_ruyuanriqi;
        private System.Windows.Forms.TextBox txt_chuangweihao;
        private System.Windows.Forms.TextBox txt_jiezhiriqi;
        private System.Windows.Forms.TextBox txt_weijiefeiyong;
        private System.Windows.Forms.TextBox txt_zifeixiaoji;
        private System.Windows.Forms.TextBox txt_gerenzhifu;
        private System.Windows.Forms.TextBox txt_zhuyuanzhuangtai;
        private System.Windows.Forms.TextBox txt_yinger;
        private System.Windows.Forms.TextBox txt_yinshuafapiao;
        private System.Windows.Forms.TextBox txt_shoutuizhipiao;
        private System.Windows.Forms.TextBox txt_shoutuixianjin;

    }
}