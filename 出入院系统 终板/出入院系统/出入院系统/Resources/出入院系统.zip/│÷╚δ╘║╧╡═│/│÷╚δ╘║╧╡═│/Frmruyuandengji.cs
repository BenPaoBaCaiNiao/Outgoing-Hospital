﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace 出入院系统
{
    public partial class Frmruyuandengji : Form
    {
        public Frmruyuandengji()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void but_chakan_Click(object sender, EventArgs e)
        {
              if(txb_menzhenNo.Text.Trim()=="")
            {
                MessageBox.Show("请输入门诊号");
                txb_menzhenNo.Focus();
                return;
        }
            SqlConnection sqlconnection=new SqlConnection();
            sqlconnection.ConnectionString =
                "server=(local);DataBase=EduBaseHos;Integrated Security=sspi";
            SqlCommand sqlcommand=sqlconnection.CreateCommand();
            sqlcommand.CommandText =
                "select bianma,zhenduanday,keshiname,shuoming from tb_keshi k join tb_zhenduan z on k.keshiNo=z.keshiNo where menNo=@menNo;";
            sqlcommand.Parameters.AddWithValue("@menNo",this.txb_menzhenNo.Text.Trim());

            sqlconnection.Open();
            SqlDataReader data=sqlcommand.ExecuteReader();
            if(data.Read())
            {
                
                this.txb_zhenduandetail.Text=data["shuoming"].ToString();
                this.txb_zhenduanma.Text=data["bianma"].ToString();
                this.txb_menzhenday.Text=data["zhenduanday"].ToString();
                this.txb_keshi.Text=data["keshiname"].ToString();
            }
            else
            {
                MessageBox.Show("不存在该病人");
                return;
            }
            sqlconnection.Close();
                            
        }

        private void but_chaxun_Click(object sender, EventArgs e)
        {
                  if(this.txb_zuyuanNo.Text.Trim()=="")
            {
                MessageBox.Show("请输住院号");
                this.txb_zuyuanNo.Focus();
                return;
            }
           SqlConnection sqlconnection=new SqlConnection();
            sqlconnection.ConnectionString =
                "server=(local);Database=EduBaseHos;Integrated Security=sspi";
            SqlCommand sqlcomamnd=sqlconnection.CreateCommand();
            sqlcomamnd.CommandText  =
                "select * from tb_base b join tb_hosbase h on b.zuNo=h.zuNo where b.zuNo=@zuyuanNo";
            sqlcomamnd.Parameters.AddWithValue("@zuyuanNo",this.txb_zuyuanNo.Text.Trim());
            sqlconnection.Open();
            SqlDataReader datareader=sqlcomamnd.ExecuteReader() ;

            if(datareader.Read())
            {
                txb_name.Text=datareader["paname"].ToString();
                txb_idNo.Text=datareader["idNo"].ToString();
                txb_address.Text=datareader["homead"].ToString();
                dt_birthday.Text = ((DateTime)datareader["birthdate"]).ToShortDateString() ;
                txb_country.Text=datareader["guoji"].ToString();
                txb_email.Text=datareader["email"].ToString();
                txb_job.Text=datareader["profession"].ToString();
                dt_ruyuanday.Text = datareader["rudate"].ToString();
                txb_ruyuantime.Text = datareader["rutime"].ToString();
                txb_jistyle.Text = datareader["jistyle"].ToString();
                txb_email.Text = datareader["email"].ToString();
                if(datareader["marryorno"].ToString()=="1")
                {
                    txb_marry.Text="是";
                }
                else
                {
                    txb_marry.Text="否";
                }
                txb_minzhu.Text=datareader["minzhu"].ToString();
                txb_phone.Text=datareader["telephone"].ToString();
                txb_relation.Text=datareader["relation"].ToString();
                txb_relationname.Text=datareader["familyname"].ToString();
            }
            sqlconnection.Close();
        }

        private void but_bedcheck_Click(object sender, EventArgs e)
        {
            
        }
        }
    }
