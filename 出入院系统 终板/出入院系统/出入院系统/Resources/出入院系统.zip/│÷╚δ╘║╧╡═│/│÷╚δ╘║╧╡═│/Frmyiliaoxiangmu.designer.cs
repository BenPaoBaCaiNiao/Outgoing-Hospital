﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_xuhao = new System.Windows.Forms.Label();
            this.Txt_xuhao = new System.Windows.Forms.TextBox();
            this.LB_zhuyuanhao = new System.Windows.Forms.Label();
            this.Ttx_zhuyuanhao = new System.Windows.Forms.TextBox();
            this.LLB_shoufeibianhao = new System.Windows.Forms.Label();
            this.Txt_shoufeibianhao = new System.Windows.Forms.TextBox();
            this.LB_shoufeimingcheng = new System.Windows.Forms.Label();
            this.Txt_shoufeimingcheng = new System.Windows.Forms.TextBox();
            this.LB_guige = new System.Windows.Forms.Label();
            this.Txt_guige = new System.Windows.Forms.TextBox();
            this.LB_shuliang = new System.Windows.Forms.Label();
            this.Txt_shulinag = new System.Windows.Forms.TextBox();
            this.LB_jine = new System.Windows.Forms.Label();
            this.Txt_jine = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // LB_xuhao
            // 
            this.LB_xuhao.AutoSize = true;
            this.LB_xuhao.Location = new System.Drawing.Point(50, 78);
            this.LB_xuhao.Name = "LB_xuhao";
            this.LB_xuhao.Size = new System.Drawing.Size(35, 12);
            this.LB_xuhao.TabIndex = 0;
            this.LB_xuhao.Text = "序号:";
            // 
            // Txt_xuhao
            // 
            this.Txt_xuhao.Location = new System.Drawing.Point(127, 50);
            this.Txt_xuhao.Multiline = true;
            this.Txt_xuhao.Name = "Txt_xuhao";
            this.Txt_xuhao.Size = new System.Drawing.Size(139, 40);
            this.Txt_xuhao.TabIndex = 1;
            // 
            // LB_zhuyuanhao
            // 
            this.LB_zhuyuanhao.AutoSize = true;
            this.LB_zhuyuanhao.Location = new System.Drawing.Point(52, 217);
            this.LB_zhuyuanhao.Name = "LB_zhuyuanhao";
            this.LB_zhuyuanhao.Size = new System.Drawing.Size(53, 12);
            this.LB_zhuyuanhao.TabIndex = 2;
            this.LB_zhuyuanhao.Text = "住院号：";
            // 
            // Ttx_zhuyuanhao
            // 
            this.Ttx_zhuyuanhao.Location = new System.Drawing.Point(127, 197);
            this.Ttx_zhuyuanhao.Multiline = true;
            this.Ttx_zhuyuanhao.Name = "Ttx_zhuyuanhao";
            this.Ttx_zhuyuanhao.Size = new System.Drawing.Size(139, 41);
            this.Ttx_zhuyuanhao.TabIndex = 3;
            // 
            // LLB_shoufeibianhao
            // 
            this.LLB_shoufeibianhao.AutoSize = true;
            this.LLB_shoufeibianhao.Location = new System.Drawing.Point(52, 371);
            this.LLB_shoufeibianhao.Name = "LLB_shoufeibianhao";
            this.LLB_shoufeibianhao.Size = new System.Drawing.Size(65, 12);
            this.LLB_shoufeibianhao.TabIndex = 4;
            this.LLB_shoufeibianhao.Text = "收费编号：";
            // 
            // Txt_shoufeibianhao
            // 
            this.Txt_shoufeibianhao.Location = new System.Drawing.Point(127, 345);
            this.Txt_shoufeibianhao.Multiline = true;
            this.Txt_shoufeibianhao.Name = "Txt_shoufeibianhao";
            this.Txt_shoufeibianhao.Size = new System.Drawing.Size(144, 37);
            this.Txt_shoufeibianhao.TabIndex = 5;
            // 
            // LB_shoufeimingcheng
            // 
            this.LB_shoufeimingcheng.AutoSize = true;
            this.LB_shoufeimingcheng.Location = new System.Drawing.Point(52, 473);
            this.LB_shoufeimingcheng.Name = "LB_shoufeimingcheng";
            this.LB_shoufeimingcheng.Size = new System.Drawing.Size(65, 12);
            this.LB_shoufeimingcheng.TabIndex = 6;
            this.LB_shoufeimingcheng.Text = "收费名称：";
            // 
            // Txt_shoufeimingcheng
            // 
            this.Txt_shoufeimingcheng.Location = new System.Drawing.Point(127, 451);
            this.Txt_shoufeimingcheng.Multiline = true;
            this.Txt_shoufeimingcheng.Name = "Txt_shoufeimingcheng";
            this.Txt_shoufeimingcheng.Size = new System.Drawing.Size(156, 43);
            this.Txt_shoufeimingcheng.TabIndex = 7;
            // 
            // LB_guige
            // 
            this.LB_guige.AutoSize = true;
            this.LB_guige.Location = new System.Drawing.Point(398, 69);
            this.LB_guige.Name = "LB_guige";
            this.LB_guige.Size = new System.Drawing.Size(41, 12);
            this.LB_guige.TabIndex = 8;
            this.LB_guige.Text = "规格：";
            // 
            // Txt_guige
            // 
            this.Txt_guige.Location = new System.Drawing.Point(492, 50);
            this.Txt_guige.Multiline = true;
            this.Txt_guige.Name = "Txt_guige";
            this.Txt_guige.Size = new System.Drawing.Size(140, 40);
            this.Txt_guige.TabIndex = 9;
            // 
            // LB_shuliang
            // 
            this.LB_shuliang.AutoSize = true;
            this.LB_shuliang.Location = new System.Drawing.Point(400, 216);
            this.LB_shuliang.Name = "LB_shuliang";
            this.LB_shuliang.Size = new System.Drawing.Size(41, 12);
            this.LB_shuliang.TabIndex = 10;
            this.LB_shuliang.Text = "数量：";
            this.LB_shuliang.Click += new System.EventHandler(this.LB_shuliang_Click);
            // 
            // Txt_shulinag
            // 
            this.Txt_shulinag.Location = new System.Drawing.Point(492, 185);
            this.Txt_shulinag.Multiline = true;
            this.Txt_shulinag.Name = "Txt_shulinag";
            this.Txt_shulinag.Size = new System.Drawing.Size(140, 42);
            this.Txt_shulinag.TabIndex = 11;
            // 
            // LB_jine
            // 
            this.LB_jine.AutoSize = true;
            this.LB_jine.Location = new System.Drawing.Point(400, 369);
            this.LB_jine.Name = "LB_jine";
            this.LB_jine.Size = new System.Drawing.Size(41, 12);
            this.LB_jine.TabIndex = 12;
            this.LB_jine.Text = "金额：";
            // 
            // Txt_jine
            // 
            this.Txt_jine.Location = new System.Drawing.Point(492, 345);
            this.Txt_jine.Multiline = true;
            this.Txt_jine.Name = "Txt_jine";
            this.Txt_jine.Size = new System.Drawing.Size(151, 45);
            this.Txt_jine.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 632);
            this.Controls.Add(this.Txt_jine);
            this.Controls.Add(this.LB_jine);
            this.Controls.Add(this.Txt_shulinag);
            this.Controls.Add(this.LB_shuliang);
            this.Controls.Add(this.Txt_guige);
            this.Controls.Add(this.LB_guige);
            this.Controls.Add(this.Txt_shoufeimingcheng);
            this.Controls.Add(this.LB_shoufeimingcheng);
            this.Controls.Add(this.Txt_shoufeibianhao);
            this.Controls.Add(this.LLB_shoufeibianhao);
            this.Controls.Add(this.Ttx_zhuyuanhao);
            this.Controls.Add(this.LB_zhuyuanhao);
            this.Controls.Add(this.Txt_xuhao);
            this.Controls.Add(this.LB_xuhao);
            this.Name = "Form1";
            this.Text = "医疗项目";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_xuhao;
        private System.Windows.Forms.TextBox Txt_xuhao;
        private System.Windows.Forms.Label LB_zhuyuanhao;
        private System.Windows.Forms.TextBox Ttx_zhuyuanhao;
        private System.Windows.Forms.Label LLB_shoufeibianhao;
        private System.Windows.Forms.TextBox Txt_shoufeibianhao;
        private System.Windows.Forms.Label LB_shoufeimingcheng;
        private System.Windows.Forms.TextBox Txt_shoufeimingcheng;
        private System.Windows.Forms.Label LB_guige;
        private System.Windows.Forms.TextBox Txt_guige;
        private System.Windows.Forms.Label LB_shuliang;
        private System.Windows.Forms.TextBox Txt_shulinag;
        private System.Windows.Forms.Label LB_jine;
        private System.Windows.Forms.TextBox Txt_jine;
    }
}

