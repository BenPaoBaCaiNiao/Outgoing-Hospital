﻿namespace WindowsFormsApplication2
{
    partial class 发票信息查询
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_fapiaobianhao = new System.Windows.Forms.Label();
            this.Txt_fapaiobianhao = new System.Windows.Forms.TextBox();
            this.LB_zhuyuanhao = new System.Windows.Forms.Label();
            this.Txt_zhuyuanhao = new System.Windows.Forms.TextBox();
            this.LB_zongjine = new System.Windows.Forms.Label();
            this.LB_zhifujine = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.Txt_zhifujine = new System.Windows.Forms.TextBox();
            this.LB_jizhangjine = new System.Windows.Forms.Label();
            this.Txt_jizhnagjine = new System.Windows.Forms.TextBox();
            this.LB_zhuangtai = new System.Windows.Forms.Label();
            this.LB_jiezhnagriqi = new System.Windows.Forms.Label();
            this.Txt_jiezhnagriqi = new System.Windows.Forms.TextBox();
            this.LB_jiezhnaggonghao = new System.Windows.Forms.Label();
            this.Txt_jiezhnaggonghao = new System.Windows.Forms.TextBox();
            this.CheB_zhuangtai = new System.Windows.Forms.CheckedListBox();
            this.SuspendLayout();
            // 
            // LB_fapiaobianhao
            // 
            this.LB_fapiaobianhao.AutoSize = true;
            this.LB_fapiaobianhao.Location = new System.Drawing.Point(64, 114);
            this.LB_fapiaobianhao.Name = "LB_fapiaobianhao";
            this.LB_fapiaobianhao.Size = new System.Drawing.Size(65, 12);
            this.LB_fapiaobianhao.TabIndex = 0;
            this.LB_fapiaobianhao.Text = "发票编号：";
            // 
            // Txt_fapaiobianhao
            // 
            this.Txt_fapaiobianhao.Location = new System.Drawing.Point(142, 92);
            this.Txt_fapaiobianhao.Multiline = true;
            this.Txt_fapaiobianhao.Name = "Txt_fapaiobianhao";
            this.Txt_fapaiobianhao.Size = new System.Drawing.Size(116, 50);
            this.Txt_fapaiobianhao.TabIndex = 1;
            // 
            // LB_zhuyuanhao
            // 
            this.LB_zhuyuanhao.AutoSize = true;
            this.LB_zhuyuanhao.Location = new System.Drawing.Point(62, 229);
            this.LB_zhuyuanhao.Name = "LB_zhuyuanhao";
            this.LB_zhuyuanhao.Size = new System.Drawing.Size(53, 12);
            this.LB_zhuyuanhao.TabIndex = 2;
            this.LB_zhuyuanhao.Text = "住院号：";
            // 
            // Txt_zhuyuanhao
            // 
            this.Txt_zhuyuanhao.Location = new System.Drawing.Point(142, 205);
            this.Txt_zhuyuanhao.Multiline = true;
            this.Txt_zhuyuanhao.Name = "Txt_zhuyuanhao";
            this.Txt_zhuyuanhao.Size = new System.Drawing.Size(116, 45);
            this.Txt_zhuyuanhao.TabIndex = 3;
            // 
            // LB_zongjine
            // 
            this.LB_zongjine.AutoSize = true;
            this.LB_zongjine.Location = new System.Drawing.Point(64, 347);
            this.LB_zongjine.Name = "LB_zongjine";
            this.LB_zongjine.Size = new System.Drawing.Size(53, 12);
            this.LB_zongjine.TabIndex = 4;
            this.LB_zongjine.Text = "总金额：";
            // 
            // LB_zhifujine
            // 
            this.LB_zhifujine.AutoSize = true;
            this.LB_zhifujine.Location = new System.Drawing.Point(64, 457);
            this.LB_zhifujine.Name = "LB_zhifujine";
            this.LB_zhifujine.Size = new System.Drawing.Size(65, 12);
            this.LB_zhifujine.TabIndex = 5;
            this.LB_zhifujine.Text = "支付金额：";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(142, 311);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(116, 47);
            this.textBox3.TabIndex = 6;
            // 
            // Txt_zhifujine
            // 
            this.Txt_zhifujine.Location = new System.Drawing.Point(142, 425);
            this.Txt_zhifujine.Multiline = true;
            this.Txt_zhifujine.Name = "Txt_zhifujine";
            this.Txt_zhifujine.Size = new System.Drawing.Size(116, 43);
            this.Txt_zhifujine.TabIndex = 7;
            // 
            // LB_jizhangjine
            // 
            this.LB_jizhangjine.AutoSize = true;
            this.LB_jizhangjine.Location = new System.Drawing.Point(371, 114);
            this.LB_jizhangjine.Name = "LB_jizhangjine";
            this.LB_jizhangjine.Size = new System.Drawing.Size(65, 12);
            this.LB_jizhangjine.TabIndex = 8;
            this.LB_jizhangjine.Text = "记账金额：";
            // 
            // Txt_jizhnagjine
            // 
            this.Txt_jizhnagjine.Location = new System.Drawing.Point(470, 92);
            this.Txt_jizhnagjine.Multiline = true;
            this.Txt_jizhnagjine.Name = "Txt_jizhnagjine";
            this.Txt_jizhnagjine.Size = new System.Drawing.Size(135, 50);
            this.Txt_jizhnagjine.TabIndex = 9;
            // 
            // LB_zhuangtai
            // 
            this.LB_zhuangtai.AutoSize = true;
            this.LB_zhuangtai.Location = new System.Drawing.Point(373, 229);
            this.LB_zhuangtai.Name = "LB_zhuangtai";
            this.LB_zhuangtai.Size = new System.Drawing.Size(41, 12);
            this.LB_zhuangtai.TabIndex = 10;
            this.LB_zhuangtai.Text = "状态：";
            this.LB_zhuangtai.Click += new System.EventHandler(this.label6_Click);
            // 
            // LB_jiezhnagriqi
            // 
            this.LB_jiezhnagriqi.AutoSize = true;
            this.LB_jiezhnagriqi.Location = new System.Drawing.Point(375, 345);
            this.LB_jiezhnagriqi.Name = "LB_jiezhnagriqi";
            this.LB_jiezhnagriqi.Size = new System.Drawing.Size(65, 12);
            this.LB_jiezhnagriqi.TabIndex = 12;
            this.LB_jiezhnagriqi.Text = "结账日期：";
            // 
            // Txt_jiezhnagriqi
            // 
            this.Txt_jiezhnagriqi.Location = new System.Drawing.Point(470, 311);
            this.Txt_jiezhnagriqi.Multiline = true;
            this.Txt_jiezhnagriqi.Name = "Txt_jiezhnagriqi";
            this.Txt_jiezhnagriqi.Size = new System.Drawing.Size(135, 47);
            this.Txt_jiezhnagriqi.TabIndex = 13;
            // 
            // LB_jiezhnaggonghao
            // 
            this.LB_jiezhnaggonghao.AutoSize = true;
            this.LB_jiezhnaggonghao.Location = new System.Drawing.Point(375, 455);
            this.LB_jiezhnaggonghao.Name = "LB_jiezhnaggonghao";
            this.LB_jiezhnaggonghao.Size = new System.Drawing.Size(65, 12);
            this.LB_jiezhnaggonghao.TabIndex = 14;
            this.LB_jiezhnaggonghao.Text = "结账工号：";
            // 
            // Txt_jiezhnaggonghao
            // 
            this.Txt_jiezhnaggonghao.Location = new System.Drawing.Point(470, 425);
            this.Txt_jiezhnaggonghao.Multiline = true;
            this.Txt_jiezhnaggonghao.Name = "Txt_jiezhnaggonghao";
            this.Txt_jiezhnaggonghao.Size = new System.Drawing.Size(135, 48);
            this.Txt_jiezhnaggonghao.TabIndex = 15;
            // 
            // CheB_zhuangtai
            // 
            this.CheB_zhuangtai.FormattingEnabled = true;
            this.CheB_zhuangtai.Location = new System.Drawing.Point(470, 198);
            this.CheB_zhuangtai.Name = "CheB_zhuangtai";
            this.CheB_zhuangtai.Size = new System.Drawing.Size(135, 52);
            this.CheB_zhuangtai.TabIndex = 16;
            // 
            // 发票信息查询
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 593);
            this.Controls.Add(this.CheB_zhuangtai);
            this.Controls.Add(this.Txt_jiezhnaggonghao);
            this.Controls.Add(this.LB_jiezhnaggonghao);
            this.Controls.Add(this.Txt_jiezhnagriqi);
            this.Controls.Add(this.LB_jiezhnagriqi);
            this.Controls.Add(this.LB_zhuangtai);
            this.Controls.Add(this.Txt_jizhnagjine);
            this.Controls.Add(this.LB_jizhangjine);
            this.Controls.Add(this.Txt_zhifujine);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.LB_zhifujine);
            this.Controls.Add(this.LB_zongjine);
            this.Controls.Add(this.Txt_zhuyuanhao);
            this.Controls.Add(this.LB_zhuyuanhao);
            this.Controls.Add(this.Txt_fapaiobianhao);
            this.Controls.Add(this.LB_fapiaobianhao);
            this.Name = "发票信息查询";
            this.Text = "发票信息查询";
            this.Load += new System.EventHandler(this.发票信息查询_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_fapiaobianhao;
        private System.Windows.Forms.TextBox Txt_fapaiobianhao;
        private System.Windows.Forms.Label LB_zhuyuanhao;
        private System.Windows.Forms.TextBox Txt_zhuyuanhao;
        private System.Windows.Forms.Label LB_zongjine;
        private System.Windows.Forms.Label LB_zhifujine;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox Txt_zhifujine;
        private System.Windows.Forms.Label LB_jizhangjine;
        private System.Windows.Forms.TextBox Txt_jizhnagjine;
        private System.Windows.Forms.Label LB_zhuangtai;
        private System.Windows.Forms.Label LB_jiezhnagriqi;
        private System.Windows.Forms.TextBox Txt_jiezhnagriqi;
        private System.Windows.Forms.Label LB_jiezhnaggonghao;
        private System.Windows.Forms.TextBox Txt_jiezhnaggonghao;
        private System.Windows.Forms.CheckedListBox CheB_zhuangtai;
    }
}

