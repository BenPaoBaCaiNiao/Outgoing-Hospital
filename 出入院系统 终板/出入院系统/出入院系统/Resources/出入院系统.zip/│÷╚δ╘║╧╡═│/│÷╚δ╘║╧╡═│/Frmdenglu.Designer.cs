﻿namespace 出入院系统
{
    partial class Frmdenglu
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_yonghu = new System.Windows.Forms.Label();
            this.lb_mima = new System.Windows.Forms.Label();
            this.txt_yonghu = new System.Windows.Forms.TextBox();
            this.txt_mima = new System.Windows.Forms.TextBox();
            this.but_denglu = new System.Windows.Forms.Button();
            this.but_quxiao = new System.Windows.Forms.Button();
            this.lkb_zhuce = new System.Windows.Forms.LinkLabel();
            this.lkb_xianshi = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // lb_yonghu
            // 
            this.lb_yonghu.AutoSize = true;
            this.lb_yonghu.BackColor = System.Drawing.Color.Transparent;
            this.lb_yonghu.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_yonghu.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lb_yonghu.Location = new System.Drawing.Point(123, 102);
            this.lb_yonghu.Name = "lb_yonghu";
            this.lb_yonghu.Size = new System.Drawing.Size(69, 19);
            this.lb_yonghu.TabIndex = 0;
            this.lb_yonghu.Text = "用户名";
            this.lb_yonghu.Click += new System.EventHandler(this.label1_Click);
            // 
            // lb_mima
            // 
            this.lb_mima.AutoSize = true;
            this.lb_mima.BackColor = System.Drawing.Color.Transparent;
            this.lb_mima.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_mima.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lb_mima.Location = new System.Drawing.Point(133, 170);
            this.lb_mima.Name = "lb_mima";
            this.lb_mima.Size = new System.Drawing.Size(49, 19);
            this.lb_mima.TabIndex = 1;
            this.lb_mima.Text = "密码";
            // 
            // txt_yonghu
            // 
            this.txt_yonghu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_yonghu.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_yonghu.Location = new System.Drawing.Point(245, 99);
            this.txt_yonghu.Name = "txt_yonghu";
            this.txt_yonghu.Size = new System.Drawing.Size(202, 22);
            this.txt_yonghu.TabIndex = 2;
            // 
            // txt_mima
            // 
            this.txt_mima.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_mima.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_mima.Location = new System.Drawing.Point(245, 160);
            this.txt_mima.Name = "txt_mima";
            this.txt_mima.PasswordChar = '*';
            this.txt_mima.Size = new System.Drawing.Size(202, 22);
            this.txt_mima.TabIndex = 3;
            // 
            // but_denglu
            // 
            this.but_denglu.BackColor = System.Drawing.Color.Transparent;
            this.but_denglu.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.but_denglu.ForeColor = System.Drawing.SystemColors.ControlText;
            this.but_denglu.Location = new System.Drawing.Point(213, 259);
            this.but_denglu.Name = "but_denglu";
            this.but_denglu.Size = new System.Drawing.Size(117, 37);
            this.but_denglu.TabIndex = 4;
            this.but_denglu.Text = "登录";
            this.but_denglu.UseVisualStyleBackColor = false;
            this.but_denglu.Click += new System.EventHandler(this.button1_Click);
            // 
            // but_quxiao
            // 
            this.but_quxiao.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.but_quxiao.Location = new System.Drawing.Point(363, 259);
            this.but_quxiao.Name = "but_quxiao";
            this.but_quxiao.Size = new System.Drawing.Size(118, 37);
            this.but_quxiao.TabIndex = 5;
            this.but_quxiao.Text = "取消";
            this.but_quxiao.UseVisualStyleBackColor = true;
            this.but_quxiao.Click += new System.EventHandler(this.but_quxiao_Click_1);
            // 
            // lkb_zhuce
            // 
            this.lkb_zhuce.AutoSize = true;
            this.lkb_zhuce.BackColor = System.Drawing.Color.Transparent;
            this.lkb_zhuce.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lkb_zhuce.ForeColor = System.Drawing.Color.White;
            this.lkb_zhuce.Location = new System.Drawing.Point(504, 259);
            this.lkb_zhuce.Name = "lkb_zhuce";
            this.lkb_zhuce.Size = new System.Drawing.Size(50, 25);
            this.lkb_zhuce.TabIndex = 7;
            this.lkb_zhuce.TabStop = true;
            this.lkb_zhuce.Text = "注册";
            this.lkb_zhuce.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lkb_xianshi
            // 
            this.lkb_xianshi.AutoSize = true;
            this.lkb_xianshi.BackColor = System.Drawing.Color.Transparent;
            this.lkb_xianshi.Location = new System.Drawing.Point(491, 160);
            this.lkb_xianshi.Name = "lkb_xianshi";
            this.lkb_xianshi.Size = new System.Drawing.Size(63, 14);
            this.lkb_xianshi.TabIndex = 8;
            this.lkb_xianshi.TabStop = true;
            this.lkb_xianshi.Text = "密码显示";
            this.lkb_xianshi.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lkb_xianshi_LinkClicked);
            // 
            // Frmdenglu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::出入院系统.Properties.Resources.timg;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(709, 401);
            this.Controls.Add(this.lkb_xianshi);
            this.Controls.Add(this.lkb_zhuce);
            this.Controls.Add(this.but_quxiao);
            this.Controls.Add(this.but_denglu);
            this.Controls.Add(this.txt_mima);
            this.Controls.Add(this.txt_yonghu);
            this.Controls.Add(this.lb_mima);
            this.Controls.Add(this.lb_yonghu);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "Frmdenglu";
            this.Text = "用户登录";
            this.Load += new System.EventHandler(this.登录_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_yonghu;
        private System.Windows.Forms.Label lb_mima;
        private System.Windows.Forms.TextBox txt_yonghu;
        private System.Windows.Forms.TextBox txt_mima;
        private System.Windows.Forms.Button but_denglu;
        private System.Windows.Forms.Button but_quxiao;
        private System.Windows.Forms.LinkLabel lkb_zhuce;
        private System.Windows.Forms.LinkLabel lkb_xianshi;
    }
}

