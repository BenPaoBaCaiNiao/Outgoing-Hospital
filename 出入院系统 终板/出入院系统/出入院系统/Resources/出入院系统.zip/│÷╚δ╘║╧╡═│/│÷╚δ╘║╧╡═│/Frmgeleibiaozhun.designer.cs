﻿namespace WindowsFormsApplication3
{
    partial class LtB_shoufeibiaozun
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Txt_shoufeibianhao = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.shoufeixiangmu = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.Txt_danjia = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.Txt_jiliangdanwei = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 36);
            this.button1.TabIndex = 0;
            this.button1.Text = "收费编号：";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Txt_shoufeibianhao
            // 
            this.Txt_shoufeibianhao.Location = new System.Drawing.Point(135, 46);
            this.Txt_shoufeibianhao.Multiline = true;
            this.Txt_shoufeibianhao.Name = "Txt_shoufeibianhao";
            this.Txt_shoufeibianhao.Size = new System.Drawing.Size(138, 36);
            this.Txt_shoufeibianhao.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 118);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 39);
            this.button2.TabIndex = 2;
            this.button2.Text = "收费项目：";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // shoufeixiangmu
            // 
            this.shoufeixiangmu.Location = new System.Drawing.Point(135, 118);
            this.shoufeixiangmu.Multiline = true;
            this.shoufeixiangmu.Name = "shoufeixiangmu";
            this.shoufeixiangmu.Size = new System.Drawing.Size(138, 39);
            this.shoufeixiangmu.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 208);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(108, 43);
            this.button3.TabIndex = 4;
            this.button3.Text = "单价：";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Txt_danjia
            // 
            this.Txt_danjia.Location = new System.Drawing.Point(135, 208);
            this.Txt_danjia.Multiline = true;
            this.Txt_danjia.Name = "Txt_danjia";
            this.Txt_danjia.Size = new System.Drawing.Size(142, 43);
            this.Txt_danjia.TabIndex = 5;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(410, 46);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(115, 43);
            this.button4.TabIndex = 6;
            this.button4.Text = "计量单位：";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // Txt_jiliangdanwei
            // 
            this.Txt_jiliangdanwei.Location = new System.Drawing.Point(557, 46);
            this.Txt_jiliangdanwei.Multiline = true;
            this.Txt_jiliangdanwei.Name = "Txt_jiliangdanwei";
            this.Txt_jiliangdanwei.Size = new System.Drawing.Size(164, 43);
            this.Txt_jiliangdanwei.TabIndex = 7;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(410, 209);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(115, 42);
            this.button5.TabIndex = 8;
            this.button5.Text = "收费标准：";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 14;
            this.listBox1.Location = new System.Drawing.Point(557, 209);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(164, 46);
            this.listBox1.TabIndex = 9;
            // 
            // LtB_shoufeibiaozun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 582);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Txt_jiliangdanwei);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.Txt_danjia);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.shoufeixiangmu);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Txt_shoufeibianhao);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Name = "LtB_shoufeibiaozun";
            this.Text = "各类收入标准";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Txt_shoufeibianhao;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox shoufeixiangmu;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox Txt_danjia;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox Txt_jiliangdanwei;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ListBox listBox1;

    }
}

