﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 出入院系统
{
    public partial class Frmdenglu : Form
    {
        public Frmdenglu()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void 登录_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_yonghu.Text.Trim() == "" || txt_mima.Text.Trim() == "")
            {
                MessageBox.Show("用户或密码不可为空");
                if (txt_yonghu.Text.Trim() == "")
                {
                    this.txt_yonghu.Focus();
                }
                else
                {
                    this.txt_mima.Focus();
                }
                return;
            }
           
            this.txt_mima.PasswordChar = '*';
            SqlConnection sqlconnection = new SqlConnection();
            sqlconnection.ConnectionString =
                    "Server=(local);Database=EduBaseHos;Integrated Security=sspi";
            SqlCommand sqlcommand = sqlconnection.CreateCommand();
            sqlcommand.CommandText =
                    "SELECT COUNT(1) FROM tb_user WHERE No=@No and passwd=@passwd";
            sqlcommand.Parameters.AddWithValue("@No", this.txt_yonghu.Text.Trim());
            sqlcommand.Parameters.AddWithValue("@passwd", this.txt_mima.Text.Trim());
            sqlcommand.Parameters["@passwd"].SqlDbType = SqlDbType.VarChar;
            sqlconnection.Open();
            int row = (int)sqlcommand.ExecuteScalar();
            sqlconnection.Close();
            
            if (row == 1)
            {
                MessageBox.Show("登录成功");
            }
            else
            {
                MessageBox.Show("用户号、密码错误，请重新输入");
                this.txt_mima.Focus();
                this.txt_mima.SelectAll();
                return;
            }
            
          
            Frmruyuandengji f1 = new Frmruyuandengji();
            f1.Show();
            

        

        }

        private void but_quxiao_Click(object sender, EventArgs e)
        {
            
        }

        private void but_quxiao_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void but_zhuce_Click(object sender, EventArgs e)
        {
            Frmzhuce zhuce = new Frmzhuce();
            zhuce.Show();
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        { 
            Frmzhuce frmzhuce = new Frmzhuce();
            this.Visible = false;
            frmzhuce.ShowDialog();
            this.Visible = true;

        }

        private void lkb_xianshi_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }
    }
}
