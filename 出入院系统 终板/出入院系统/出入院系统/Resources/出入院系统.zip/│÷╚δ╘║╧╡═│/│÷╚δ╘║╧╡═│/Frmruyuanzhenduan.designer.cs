﻿namespace 出入院系统
{
    partial class Frmruyuanzhenduan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmruyuanzhenduan));
            this.lb_zhuyuan = new System.Windows.Forms.Label();
            this.txt_churuyuan = new System.Windows.Forms.TextBox();
            this.txt_zhendduanbianma = new System.Windows.Forms.TextBox();
            this.pb_tuihui = new System.Windows.Forms.PictureBox();
            this.pb_xuanze = new System.Windows.Forms.PictureBox();
            this.pb_shanchu = new System.Windows.Forms.PictureBox();
            this.pb_tianjia = new System.Windows.Forms.PictureBox();
            this.lb_leibie = new System.Windows.Forms.Label();
            this.txt_leibie = new System.Windows.Forms.TextBox();
            this.lb_daima = new System.Windows.Forms.Label();
            this.txt_daima = new System.Windows.Forms.TextBox();
            this.lb_yibaobianma = new System.Windows.Forms.Label();
            this.txt_yibaobianma = new System.Windows.Forms.TextBox();
            this.lb_biaozhunjine = new System.Windows.Forms.Label();
            this.lb_yibaojine = new System.Windows.Forms.Label();
            this.lb_jijinjine = new System.Windows.Forms.Label();
            this.txt_biaozhunjine = new System.Windows.Forms.TextBox();
            this.txt_yibaojine = new System.Windows.Forms.TextBox();
            this.txt_jijinjine = new System.Windows.Forms.TextBox();
            this.lb_jibingmingcheng = new System.Windows.Forms.Label();
            this.txt_jibingmingcheng = new System.Windows.Forms.TextBox();
            this.lb_shoupindingwei = new System.Windows.Forms.Label();
            this.txt_shoupindingwei = new System.Windows.Forms.TextBox();
            this.rb_shurumapaixu = new System.Windows.Forms.RadioButton();
            this.rb_daimapaixu = new System.Windows.Forms.RadioButton();
            this.dtp = new System.Windows.Forms.DateTimePicker();
            this.b_tianjia = new System.Windows.Forms.Button();
            this.b_shanchu = new System.Windows.Forms.Button();
            this.b_xuanze = new System.Windows.Forms.Button();
            this.b_tuihui = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tuihui)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_xuanze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shanchu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tianjia)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_zhuyuan
            // 
            this.lb_zhuyuan.AutoSize = true;
            this.lb_zhuyuan.Location = new System.Drawing.Point(12, 9);
            this.lb_zhuyuan.Name = "lb_zhuyuan";
            this.lb_zhuyuan.Size = new System.Drawing.Size(29, 12);
            this.lb_zhuyuan.TabIndex = 0;
            this.lb_zhuyuan.Text = "住院";
            this.lb_zhuyuan.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_churuyuan
            // 
            this.txt_churuyuan.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_churuyuan.Location = new System.Drawing.Point(250, 2);
            this.txt_churuyuan.Name = "txt_churuyuan";
            this.txt_churuyuan.Size = new System.Drawing.Size(162, 29);
            this.txt_churuyuan.TabIndex = 2;
            this.txt_churuyuan.Text = "出入院处理系统";
            // 
            // txt_zhendduanbianma
            // 
            this.txt_zhendduanbianma.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_zhendduanbianma.Location = new System.Drawing.Point(14, 41);
            this.txt_zhendduanbianma.Name = "txt_zhendduanbianma";
            this.txt_zhendduanbianma.Size = new System.Drawing.Size(135, 29);
            this.txt_zhendduanbianma.TabIndex = 3;
            this.txt_zhendduanbianma.Text = "入院诊断编码";
            this.txt_zhendduanbianma.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // pb_tuihui
            // 
            this.pb_tuihui.Image = global::出入院系统.Properties.Resources.退回;
            this.pb_tuihui.Location = new System.Drawing.Point(696, 41);
            this.pb_tuihui.Name = "pb_tuihui";
            this.pb_tuihui.Size = new System.Drawing.Size(27, 25);
            this.pb_tuihui.TabIndex = 10;
            this.pb_tuihui.TabStop = false;
            // 
            // pb_xuanze
            // 
            this.pb_xuanze.Image = global::出入院系统.Properties.Resources.选择1;
            this.pb_xuanze.Location = new System.Drawing.Point(608, 41);
            this.pb_xuanze.Name = "pb_xuanze";
            this.pb_xuanze.Size = new System.Drawing.Size(28, 25);
            this.pb_xuanze.TabIndex = 7;
            this.pb_xuanze.TabStop = false;
            // 
            // pb_shanchu
            // 
            this.pb_shanchu.Image = global::出入院系统.Properties.Resources.删除1;
            this.pb_shanchu.Location = new System.Drawing.Point(527, 41);
            this.pb_shanchu.Name = "pb_shanchu";
            this.pb_shanchu.Size = new System.Drawing.Size(26, 25);
            this.pb_shanchu.TabIndex = 6;
            this.pb_shanchu.TabStop = false;
            this.pb_shanchu.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pb_tianjia
            // 
            this.pb_tianjia.Image = global::出入院系统.Properties.Resources.添加２;
            this.pb_tianjia.InitialImage = ((System.Drawing.Image)(resources.GetObject("pb_tianjia.InitialImage")));
            this.pb_tianjia.Location = new System.Drawing.Point(441, 43);
            this.pb_tianjia.Name = "pb_tianjia";
            this.pb_tianjia.Size = new System.Drawing.Size(29, 24);
            this.pb_tianjia.TabIndex = 4;
            this.pb_tianjia.TabStop = false;
            // 
            // lb_leibie
            // 
            this.lb_leibie.AutoSize = true;
            this.lb_leibie.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_leibie.Location = new System.Drawing.Point(0, 87);
            this.lb_leibie.Name = "lb_leibie";
            this.lb_leibie.Size = new System.Drawing.Size(88, 16);
            this.lb_leibie.TabIndex = 12;
            this.lb_leibie.Text = "类    别：";
            // 
            // txt_leibie
            // 
            this.txt_leibie.Location = new System.Drawing.Point(76, 86);
            this.txt_leibie.Name = "txt_leibie";
            this.txt_leibie.Size = new System.Drawing.Size(100, 21);
            this.txt_leibie.TabIndex = 13;
            // 
            // lb_daima
            // 
            this.lb_daima.AutoSize = true;
            this.lb_daima.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_daima.Location = new System.Drawing.Point(0, 118);
            this.lb_daima.Name = "lb_daima";
            this.lb_daima.Size = new System.Drawing.Size(88, 16);
            this.lb_daima.TabIndex = 14;
            this.lb_daima.Text = "代    码：";
            // 
            // txt_daima
            // 
            this.txt_daima.Location = new System.Drawing.Point(76, 118);
            this.txt_daima.Name = "txt_daima";
            this.txt_daima.Size = new System.Drawing.Size(100, 21);
            this.txt_daima.TabIndex = 15;
            // 
            // lb_yibaobianma
            // 
            this.lb_yibaobianma.AutoSize = true;
            this.lb_yibaobianma.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_yibaobianma.Location = new System.Drawing.Point(0, 152);
            this.lb_yibaobianma.Name = "lb_yibaobianma";
            this.lb_yibaobianma.Size = new System.Drawing.Size(88, 16);
            this.lb_yibaobianma.TabIndex = 16;
            this.lb_yibaobianma.Text = "医保编码：";
            // 
            // txt_yibaobianma
            // 
            this.txt_yibaobianma.Location = new System.Drawing.Point(76, 147);
            this.txt_yibaobianma.Name = "txt_yibaobianma";
            this.txt_yibaobianma.Size = new System.Drawing.Size(100, 21);
            this.txt_yibaobianma.TabIndex = 17;
            // 
            // lb_biaozhunjine
            // 
            this.lb_biaozhunjine.AutoSize = true;
            this.lb_biaozhunjine.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_biaozhunjine.Location = new System.Drawing.Point(3, 186);
            this.lb_biaozhunjine.Name = "lb_biaozhunjine";
            this.lb_biaozhunjine.Size = new System.Drawing.Size(88, 16);
            this.lb_biaozhunjine.TabIndex = 18;
            this.lb_biaozhunjine.Text = "标准金额：";
            // 
            // lb_yibaojine
            // 
            this.lb_yibaojine.AutoSize = true;
            this.lb_yibaojine.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_yibaojine.Location = new System.Drawing.Point(3, 218);
            this.lb_yibaojine.Name = "lb_yibaojine";
            this.lb_yibaojine.Size = new System.Drawing.Size(88, 16);
            this.lb_yibaojine.TabIndex = 19;
            this.lb_yibaojine.Text = "医保金额：";
            // 
            // lb_jijinjine
            // 
            this.lb_jijinjine.AutoSize = true;
            this.lb_jijinjine.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_jijinjine.Location = new System.Drawing.Point(3, 252);
            this.lb_jijinjine.Name = "lb_jijinjine";
            this.lb_jijinjine.Size = new System.Drawing.Size(88, 16);
            this.lb_jijinjine.TabIndex = 20;
            this.lb_jijinjine.Text = "基金金额：";
            // 
            // txt_biaozhunjine
            // 
            this.txt_biaozhunjine.Location = new System.Drawing.Point(76, 181);
            this.txt_biaozhunjine.Name = "txt_biaozhunjine";
            this.txt_biaozhunjine.Size = new System.Drawing.Size(100, 21);
            this.txt_biaozhunjine.TabIndex = 21;
            // 
            // txt_yibaojine
            // 
            this.txt_yibaojine.Location = new System.Drawing.Point(76, 218);
            this.txt_yibaojine.Name = "txt_yibaojine";
            this.txt_yibaojine.Size = new System.Drawing.Size(100, 21);
            this.txt_yibaojine.TabIndex = 22;
            // 
            // txt_jijinjine
            // 
            this.txt_jijinjine.Location = new System.Drawing.Point(76, 252);
            this.txt_jijinjine.Name = "txt_jijinjine";
            this.txt_jijinjine.Size = new System.Drawing.Size(100, 21);
            this.txt_jijinjine.TabIndex = 23;
            // 
            // lb_jibingmingcheng
            // 
            this.lb_jibingmingcheng.AutoSize = true;
            this.lb_jibingmingcheng.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_jibingmingcheng.Location = new System.Drawing.Point(3, 290);
            this.lb_jibingmingcheng.Name = "lb_jibingmingcheng";
            this.lb_jibingmingcheng.Size = new System.Drawing.Size(88, 16);
            this.lb_jibingmingcheng.TabIndex = 24;
            this.lb_jibingmingcheng.Text = "疾病名称：";
            // 
            // txt_jibingmingcheng
            // 
            this.txt_jibingmingcheng.Location = new System.Drawing.Point(37, 318);
            this.txt_jibingmingcheng.Name = "txt_jibingmingcheng";
            this.txt_jibingmingcheng.Size = new System.Drawing.Size(139, 21);
            this.txt_jibingmingcheng.TabIndex = 25;
            // 
            // lb_shoupindingwei
            // 
            this.lb_shoupindingwei.AutoSize = true;
            this.lb_shoupindingwei.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_shoupindingwei.Location = new System.Drawing.Point(6, 352);
            this.lb_shoupindingwei.Name = "lb_shoupindingwei";
            this.lb_shoupindingwei.Size = new System.Drawing.Size(88, 16);
            this.lb_shoupindingwei.TabIndex = 26;
            this.lb_shoupindingwei.Text = "首拼定位：";
            // 
            // txt_shoupindingwei
            // 
            this.txt_shoupindingwei.Location = new System.Drawing.Point(37, 382);
            this.txt_shoupindingwei.Name = "txt_shoupindingwei";
            this.txt_shoupindingwei.Size = new System.Drawing.Size(139, 21);
            this.txt_shoupindingwei.TabIndex = 27;
            // 
            // rb_shurumapaixu
            // 
            this.rb_shurumapaixu.AutoSize = true;
            this.rb_shurumapaixu.Location = new System.Drawing.Point(37, 425);
            this.rb_shurumapaixu.Name = "rb_shurumapaixu";
            this.rb_shurumapaixu.Size = new System.Drawing.Size(95, 16);
            this.rb_shurumapaixu.TabIndex = 28;
            this.rb_shurumapaixu.TabStop = true;
            this.rb_shurumapaixu.Text = "按输入码排序";
            this.rb_shurumapaixu.UseVisualStyleBackColor = true;
            // 
            // rb_daimapaixu
            // 
            this.rb_daimapaixu.AutoSize = true;
            this.rb_daimapaixu.Location = new System.Drawing.Point(37, 448);
            this.rb_daimapaixu.Name = "rb_daimapaixu";
            this.rb_daimapaixu.Size = new System.Drawing.Size(83, 16);
            this.rb_daimapaixu.TabIndex = 29;
            this.rb_daimapaixu.TabStop = true;
            this.rb_daimapaixu.Text = "按代码排序";
            this.rb_daimapaixu.UseVisualStyleBackColor = true;
            // 
            // dtp
            // 
            this.dtp.Location = new System.Drawing.Point(557, 10);
            this.dtp.Name = "dtp";
            this.dtp.Size = new System.Drawing.Size(200, 21);
            this.dtp.TabIndex = 30;
            // 
            // b_tianjia
            // 
            this.b_tianjia.Location = new System.Drawing.Point(476, 43);
            this.b_tianjia.Name = "b_tianjia";
            this.b_tianjia.Size = new System.Drawing.Size(40, 23);
            this.b_tianjia.TabIndex = 31;
            this.b_tianjia.Text = "添加";
            this.b_tianjia.UseVisualStyleBackColor = true;
            // 
            // b_shanchu
            // 
            this.b_shanchu.Location = new System.Drawing.Point(557, 44);
            this.b_shanchu.Name = "b_shanchu";
            this.b_shanchu.Size = new System.Drawing.Size(37, 23);
            this.b_shanchu.TabIndex = 32;
            this.b_shanchu.Text = "删除";
            this.b_shanchu.UseVisualStyleBackColor = true;
            // 
            // b_xuanze
            // 
            this.b_xuanze.Location = new System.Drawing.Point(642, 44);
            this.b_xuanze.Name = "b_xuanze";
            this.b_xuanze.Size = new System.Drawing.Size(39, 23);
            this.b_xuanze.TabIndex = 33;
            this.b_xuanze.Text = "选择";
            this.b_xuanze.UseVisualStyleBackColor = true;
            // 
            // b_tuihui
            // 
            this.b_tuihui.Location = new System.Drawing.Point(729, 43);
            this.b_tuihui.Name = "b_tuihui";
            this.b_tuihui.Size = new System.Drawing.Size(37, 23);
            this.b_tuihui.TabIndex = 34;
            this.b_tuihui.Text = "退回";
            this.b_tuihui.UseVisualStyleBackColor = true;
            // 
            // Frmruyuanzhenduan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(769, 481);
            this.Controls.Add(this.b_tuihui);
            this.Controls.Add(this.b_xuanze);
            this.Controls.Add(this.b_shanchu);
            this.Controls.Add(this.b_tianjia);
            this.Controls.Add(this.dtp);
            this.Controls.Add(this.rb_daimapaixu);
            this.Controls.Add(this.rb_shurumapaixu);
            this.Controls.Add(this.txt_shoupindingwei);
            this.Controls.Add(this.lb_shoupindingwei);
            this.Controls.Add(this.txt_jibingmingcheng);
            this.Controls.Add(this.lb_jibingmingcheng);
            this.Controls.Add(this.txt_jijinjine);
            this.Controls.Add(this.txt_yibaojine);
            this.Controls.Add(this.txt_biaozhunjine);
            this.Controls.Add(this.lb_jijinjine);
            this.Controls.Add(this.lb_yibaojine);
            this.Controls.Add(this.lb_biaozhunjine);
            this.Controls.Add(this.txt_yibaobianma);
            this.Controls.Add(this.lb_yibaobianma);
            this.Controls.Add(this.txt_daima);
            this.Controls.Add(this.lb_daima);
            this.Controls.Add(this.txt_leibie);
            this.Controls.Add(this.lb_leibie);
            this.Controls.Add(this.pb_tuihui);
            this.Controls.Add(this.pb_xuanze);
            this.Controls.Add(this.pb_shanchu);
            this.Controls.Add(this.pb_tianjia);
            this.Controls.Add(this.txt_zhendduanbianma);
            this.Controls.Add(this.txt_churuyuan);
            this.Controls.Add(this.lb_zhuyuan);
            this.Name = "Frmruyuanzhenduan";
            this.Text = "入院诊断";
            ((System.ComponentModel.ISupportInitialize)(this.pb_tuihui)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_xuanze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_shanchu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_tianjia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_zhuyuan;
        private System.Windows.Forms.TextBox txt_churuyuan;
        private System.Windows.Forms.TextBox txt_zhendduanbianma;
        private System.Windows.Forms.PictureBox pb_tianjia;
        private System.Windows.Forms.PictureBox pb_shanchu;
        private System.Windows.Forms.PictureBox pb_xuanze;
        private System.Windows.Forms.PictureBox pb_tuihui;
        private System.Windows.Forms.Label lb_leibie;
        private System.Windows.Forms.TextBox txt_leibie;
        private System.Windows.Forms.Label lb_daima;
        private System.Windows.Forms.TextBox txt_daima;
        private System.Windows.Forms.Label lb_yibaobianma;
        private System.Windows.Forms.TextBox txt_yibaobianma;
        private System.Windows.Forms.Label lb_biaozhunjine;
        private System.Windows.Forms.Label lb_yibaojine;
        private System.Windows.Forms.Label lb_jijinjine;
        private System.Windows.Forms.TextBox txt_biaozhunjine;
        private System.Windows.Forms.TextBox txt_yibaojine;
        private System.Windows.Forms.TextBox txt_jijinjine;
        private System.Windows.Forms.Label lb_jibingmingcheng;
        private System.Windows.Forms.TextBox txt_jibingmingcheng;
        private System.Windows.Forms.Label lb_shoupindingwei;
        private System.Windows.Forms.TextBox txt_shoupindingwei;
        private System.Windows.Forms.RadioButton rb_shurumapaixu;
        private System.Windows.Forms.RadioButton rb_daimapaixu;
        private System.Windows.Forms.DateTimePicker dtp;
        private System.Windows.Forms.Button b_tianjia;
        private System.Windows.Forms.Button b_shanchu;
        private System.Windows.Forms.Button b_xuanze;
        private System.Windows.Forms.Button b_tuihui;
    }
}