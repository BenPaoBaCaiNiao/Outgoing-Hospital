﻿namespace 费用补账处理
{
    partial class 费用补账处理
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.费用补账处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_menzhenhao = new System.Windows.Forms.Label();
            this.lb_zhuyuhao = new System.Windows.Forms.Label();
            this.lb_bingqu = new System.Windows.Forms.Label();
            this.lb_leibie = new System.Windows.Forms.Label();
            this.lb_shuliang = new System.Windows.Forms.Label();
            this.lb_yisheng = new System.Windows.Forms.Label();
            this.lb_chuangweihao = new System.Windows.Forms.Label();
            this.lb_shuruma = new System.Windows.Forms.Label();
            this.lb_jine = new System.Windows.Forms.Label();
            this.lb_fashengri = new System.Windows.Forms.Label();
            this.lb_shifouzhuyuan = new System.Windows.Forms.Label();
            this.txt_shuliang = new System.Windows.Forms.TextBox();
            this.txt_menzhenhao = new System.Windows.Forms.TextBox();
            this.txt_bingqu = new System.Windows.Forms.TextBox();
            this.txt_leibei = new System.Windows.Forms.TextBox();
            this.txt_yisheng = new System.Windows.Forms.TextBox();
            this.txt_zhuyuanhao = new System.Windows.Forms.TextBox();
            this.txt_chuangweihao = new System.Windows.Forms.TextBox();
            this.txt_shuruma = new System.Windows.Forms.TextBox();
            this.txt_jine = new System.Windows.Forms.TextBox();
            this.txt_shifoubaoxiao = new System.Windows.Forms.TextBox();
            this.txt_shifouzhuyuan = new System.Windows.Forms.TextBox();
            this.txt_xingming = new System.Windows.Forms.TextBox();
            this.txt_suoshukeshi = new System.Windows.Forms.TextBox();
            this.txt_mingcheng = new System.Windows.Forms.TextBox();
            this.txt_jizhangkeshi = new System.Windows.Forms.TextBox();
            this.txt_suoshubingqu = new System.Windows.Forms.TextBox();
            this.lb_xingmin = new System.Windows.Forms.Label();
            this.lb_suoshukeshi = new System.Windows.Forms.Label();
            this.lb_mingcheng = new System.Windows.Forms.Label();
            this.lb_danjia = new System.Windows.Forms.Label();
            this.lb_suoshubingqu = new System.Windows.Forms.Label();
            this.lb_jizhangkeshi = new System.Windows.Forms.Label();
            this.lb_guige = new System.Windows.Forms.Label();
            this.lb_danwei = new System.Windows.Forms.Label();
            this.txt_guige = new System.Windows.Forms.TextBox();
            this.txt_danwei = new System.Windows.Forms.TextBox();
            this.txt_danjia = new System.Windows.Forms.TextBox();
            this.txt_bingrenleixing = new System.Windows.Forms.TextBox();
            this.lb_bingrenleixing = new System.Windows.Forms.Label();
            this.lb_shifoubaoxiao = new System.Windows.Forms.Label();
            this.lb_ruyuanriqi = new System.Windows.Forms.Label();
            this.txt_ruyuanriqi = new System.Windows.Forms.TextBox();
            this.txt_fashengri = new System.Windows.Forms.TextBox();
            this.bt_gufei = new System.Windows.Forms.Button();
            this.bt_qingchu = new System.Windows.Forms.Button();
            this.bt_tianjia = new System.Windows.Forms.Button();
            this.bt_shanchu = new System.Windows.Forms.Button();
            this.bt_caoyao = new System.Windows.Forms.Button();
            this.lb_jiaokuanjine = new System.Windows.Forms.Label();
            this.lb_shengyujine = new System.Windows.Forms.Label();
            this.lb_huafeijine = new System.Windows.Forms.Label();
            this.lb_xiaoji = new System.Windows.Forms.Label();
            this.txt_jiaokuanjine = new System.Windows.Forms.TextBox();
            this.txt_shengyujine = new System.Windows.Forms.TextBox();
            this.txt_huafeijine = new System.Windows.Forms.TextBox();
            this.txt_xiaoji = new System.Windows.Forms.TextBox();
            this.bt_baocun = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.日期 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.时间 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.类别 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.费用补账处理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1006, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 费用补账处理ToolStripMenuItem
            // 
            this.费用补账处理ToolStripMenuItem.Name = "费用补账处理ToolStripMenuItem";
            this.费用补账处理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.费用补账处理ToolStripMenuItem.Text = "费用补账处理";
            // 
            // lb_menzhenhao
            // 
            this.lb_menzhenhao.AutoSize = true;
            this.lb_menzhenhao.Location = new System.Drawing.Point(21, 104);
            this.lb_menzhenhao.Name = "lb_menzhenhao";
            this.lb_menzhenhao.Size = new System.Drawing.Size(53, 12);
            this.lb_menzhenhao.TabIndex = 1;
            this.lb_menzhenhao.Text = "门诊号：";
            // 
            // lb_zhuyuhao
            // 
            this.lb_zhuyuhao.AutoSize = true;
            this.lb_zhuyuhao.Location = new System.Drawing.Point(216, 104);
            this.lb_zhuyuhao.Name = "lb_zhuyuhao";
            this.lb_zhuyuhao.Size = new System.Drawing.Size(53, 12);
            this.lb_zhuyuhao.TabIndex = 2;
            this.lb_zhuyuhao.Text = "住院号：";
            // 
            // lb_bingqu
            // 
            this.lb_bingqu.AutoSize = true;
            this.lb_bingqu.Location = new System.Drawing.Point(21, 143);
            this.lb_bingqu.Name = "lb_bingqu";
            this.lb_bingqu.Size = new System.Drawing.Size(41, 12);
            this.lb_bingqu.TabIndex = 3;
            this.lb_bingqu.Text = "病区：";
            // 
            // lb_leibie
            // 
            this.lb_leibie.AutoSize = true;
            this.lb_leibie.Location = new System.Drawing.Point(21, 181);
            this.lb_leibie.Name = "lb_leibie";
            this.lb_leibie.Size = new System.Drawing.Size(41, 12);
            this.lb_leibie.TabIndex = 4;
            this.lb_leibie.Text = "类别：";
            // 
            // lb_shuliang
            // 
            this.lb_shuliang.AutoSize = true;
            this.lb_shuliang.Location = new System.Drawing.Point(21, 219);
            this.lb_shuliang.Name = "lb_shuliang";
            this.lb_shuliang.Size = new System.Drawing.Size(41, 12);
            this.lb_shuliang.TabIndex = 5;
            this.lb_shuliang.Text = "数量：";
            // 
            // lb_yisheng
            // 
            this.lb_yisheng.AutoSize = true;
            this.lb_yisheng.Location = new System.Drawing.Point(21, 259);
            this.lb_yisheng.Name = "lb_yisheng";
            this.lb_yisheng.Size = new System.Drawing.Size(41, 12);
            this.lb_yisheng.TabIndex = 6;
            this.lb_yisheng.Text = "医生：";
            // 
            // lb_chuangweihao
            // 
            this.lb_chuangweihao.AutoSize = true;
            this.lb_chuangweihao.Location = new System.Drawing.Point(216, 143);
            this.lb_chuangweihao.Name = "lb_chuangweihao";
            this.lb_chuangweihao.Size = new System.Drawing.Size(53, 12);
            this.lb_chuangweihao.TabIndex = 7;
            this.lb_chuangweihao.Text = "床位号：";
            // 
            // lb_shuruma
            // 
            this.lb_shuruma.AutoSize = true;
            this.lb_shuruma.Location = new System.Drawing.Point(216, 181);
            this.lb_shuruma.Name = "lb_shuruma";
            this.lb_shuruma.Size = new System.Drawing.Size(53, 12);
            this.lb_shuruma.TabIndex = 8;
            this.lb_shuruma.Text = "输入码：";
            // 
            // lb_jine
            // 
            this.lb_jine.AutoSize = true;
            this.lb_jine.Location = new System.Drawing.Point(216, 219);
            this.lb_jine.Name = "lb_jine";
            this.lb_jine.Size = new System.Drawing.Size(41, 12);
            this.lb_jine.TabIndex = 9;
            this.lb_jine.Text = "金额：";
            // 
            // lb_fashengri
            // 
            this.lb_fashengri.AutoSize = true;
            this.lb_fashengri.Location = new System.Drawing.Point(216, 265);
            this.lb_fashengri.Name = "lb_fashengri";
            this.lb_fashengri.Size = new System.Drawing.Size(53, 12);
            this.lb_fashengri.TabIndex = 10;
            this.lb_fashengri.Text = "发生日：";
            // 
            // lb_shifouzhuyuan
            // 
            this.lb_shifouzhuyuan.AutoSize = true;
            this.lb_shifouzhuyuan.Location = new System.Drawing.Point(433, 311);
            this.lb_shifouzhuyuan.Name = "lb_shifouzhuyuan";
            this.lb_shifouzhuyuan.Size = new System.Drawing.Size(65, 12);
            this.lb_shifouzhuyuan.TabIndex = 11;
            this.lb_shifouzhuyuan.Text = "是否住院：";
            // 
            // txt_shuliang
            // 
            this.txt_shuliang.Location = new System.Drawing.Point(81, 216);
            this.txt_shuliang.Name = "txt_shuliang";
            this.txt_shuliang.Size = new System.Drawing.Size(100, 21);
            this.txt_shuliang.TabIndex = 12;
            // 
            // txt_menzhenhao
            // 
            this.txt_menzhenhao.Location = new System.Drawing.Point(81, 101);
            this.txt_menzhenhao.Name = "txt_menzhenhao";
            this.txt_menzhenhao.Size = new System.Drawing.Size(100, 21);
            this.txt_menzhenhao.TabIndex = 13;
            // 
            // txt_bingqu
            // 
            this.txt_bingqu.Location = new System.Drawing.Point(81, 140);
            this.txt_bingqu.Name = "txt_bingqu";
            this.txt_bingqu.Size = new System.Drawing.Size(100, 21);
            this.txt_bingqu.TabIndex = 14;
            // 
            // txt_leibei
            // 
            this.txt_leibei.Location = new System.Drawing.Point(81, 178);
            this.txt_leibei.Name = "txt_leibei";
            this.txt_leibei.Size = new System.Drawing.Size(100, 21);
            this.txt_leibei.TabIndex = 15;
            // 
            // txt_yisheng
            // 
            this.txt_yisheng.Location = new System.Drawing.Point(81, 259);
            this.txt_yisheng.Name = "txt_yisheng";
            this.txt_yisheng.Size = new System.Drawing.Size(100, 21);
            this.txt_yisheng.TabIndex = 16;
            // 
            // txt_zhuyuanhao
            // 
            this.txt_zhuyuanhao.Location = new System.Drawing.Point(292, 101);
            this.txt_zhuyuanhao.Name = "txt_zhuyuanhao";
            this.txt_zhuyuanhao.Size = new System.Drawing.Size(100, 21);
            this.txt_zhuyuanhao.TabIndex = 17;
            // 
            // txt_chuangweihao
            // 
            this.txt_chuangweihao.Location = new System.Drawing.Point(292, 134);
            this.txt_chuangweihao.Name = "txt_chuangweihao";
            this.txt_chuangweihao.Size = new System.Drawing.Size(100, 21);
            this.txt_chuangweihao.TabIndex = 18;
            // 
            // txt_shuruma
            // 
            this.txt_shuruma.Location = new System.Drawing.Point(292, 178);
            this.txt_shuruma.Name = "txt_shuruma";
            this.txt_shuruma.Size = new System.Drawing.Size(100, 21);
            this.txt_shuruma.TabIndex = 19;
            // 
            // txt_jine
            // 
            this.txt_jine.Location = new System.Drawing.Point(292, 216);
            this.txt_jine.Name = "txt_jine";
            this.txt_jine.Size = new System.Drawing.Size(100, 21);
            this.txt_jine.TabIndex = 20;
            // 
            // txt_shifoubaoxiao
            // 
            this.txt_shifoubaoxiao.Location = new System.Drawing.Point(522, 259);
            this.txt_shifoubaoxiao.Name = "txt_shifoubaoxiao";
            this.txt_shifoubaoxiao.Size = new System.Drawing.Size(100, 21);
            this.txt_shifoubaoxiao.TabIndex = 22;
            // 
            // txt_shifouzhuyuan
            // 
            this.txt_shifouzhuyuan.Location = new System.Drawing.Point(522, 308);
            this.txt_shifouzhuyuan.Name = "txt_shifouzhuyuan";
            this.txt_shifouzhuyuan.Size = new System.Drawing.Size(100, 21);
            this.txt_shifouzhuyuan.TabIndex = 23;
            // 
            // txt_xingming
            // 
            this.txt_xingming.Location = new System.Drawing.Point(522, 101);
            this.txt_xingming.Name = "txt_xingming";
            this.txt_xingming.Size = new System.Drawing.Size(100, 21);
            this.txt_xingming.TabIndex = 24;
            // 
            // txt_suoshukeshi
            // 
            this.txt_suoshukeshi.Location = new System.Drawing.Point(522, 143);
            this.txt_suoshukeshi.Name = "txt_suoshukeshi";
            this.txt_suoshukeshi.Size = new System.Drawing.Size(100, 21);
            this.txt_suoshukeshi.TabIndex = 25;
            // 
            // txt_mingcheng
            // 
            this.txt_mingcheng.Location = new System.Drawing.Point(522, 178);
            this.txt_mingcheng.Name = "txt_mingcheng";
            this.txt_mingcheng.Size = new System.Drawing.Size(100, 21);
            this.txt_mingcheng.TabIndex = 26;
            // 
            // txt_jizhangkeshi
            // 
            this.txt_jizhangkeshi.Location = new System.Drawing.Point(737, 178);
            this.txt_jizhangkeshi.Name = "txt_jizhangkeshi";
            this.txt_jizhangkeshi.Size = new System.Drawing.Size(100, 21);
            this.txt_jizhangkeshi.TabIndex = 27;
            // 
            // txt_suoshubingqu
            // 
            this.txt_suoshubingqu.Location = new System.Drawing.Point(737, 137);
            this.txt_suoshubingqu.Name = "txt_suoshubingqu";
            this.txt_suoshubingqu.Size = new System.Drawing.Size(100, 21);
            this.txt_suoshubingqu.TabIndex = 28;
            // 
            // lb_xingmin
            // 
            this.lb_xingmin.AutoSize = true;
            this.lb_xingmin.Location = new System.Drawing.Point(433, 104);
            this.lb_xingmin.Name = "lb_xingmin";
            this.lb_xingmin.Size = new System.Drawing.Size(41, 12);
            this.lb_xingmin.TabIndex = 29;
            this.lb_xingmin.Text = "姓名：";
            // 
            // lb_suoshukeshi
            // 
            this.lb_suoshukeshi.AutoSize = true;
            this.lb_suoshukeshi.Location = new System.Drawing.Point(433, 146);
            this.lb_suoshukeshi.Name = "lb_suoshukeshi";
            this.lb_suoshukeshi.Size = new System.Drawing.Size(65, 12);
            this.lb_suoshukeshi.TabIndex = 30;
            this.lb_suoshukeshi.Text = "所属科室：";
            // 
            // lb_mingcheng
            // 
            this.lb_mingcheng.AutoSize = true;
            this.lb_mingcheng.Location = new System.Drawing.Point(433, 181);
            this.lb_mingcheng.Name = "lb_mingcheng";
            this.lb_mingcheng.Size = new System.Drawing.Size(41, 12);
            this.lb_mingcheng.TabIndex = 31;
            this.lb_mingcheng.Text = "名称：";
            // 
            // lb_danjia
            // 
            this.lb_danjia.AutoSize = true;
            this.lb_danjia.Location = new System.Drawing.Point(433, 219);
            this.lb_danjia.Name = "lb_danjia";
            this.lb_danjia.Size = new System.Drawing.Size(41, 12);
            this.lb_danjia.TabIndex = 32;
            this.lb_danjia.Text = "单价：";
            // 
            // lb_suoshubingqu
            // 
            this.lb_suoshubingqu.AutoSize = true;
            this.lb_suoshubingqu.Location = new System.Drawing.Point(668, 143);
            this.lb_suoshubingqu.Name = "lb_suoshubingqu";
            this.lb_suoshubingqu.Size = new System.Drawing.Size(65, 12);
            this.lb_suoshubingqu.TabIndex = 33;
            this.lb_suoshubingqu.Text = "所属病区：";
            // 
            // lb_jizhangkeshi
            // 
            this.lb_jizhangkeshi.AutoSize = true;
            this.lb_jizhangkeshi.Location = new System.Drawing.Point(668, 181);
            this.lb_jizhangkeshi.Name = "lb_jizhangkeshi";
            this.lb_jizhangkeshi.Size = new System.Drawing.Size(65, 12);
            this.lb_jizhangkeshi.TabIndex = 34;
            this.lb_jizhangkeshi.Text = "记账科室：";
            // 
            // lb_guige
            // 
            this.lb_guige.AutoSize = true;
            this.lb_guige.Location = new System.Drawing.Point(668, 219);
            this.lb_guige.Name = "lb_guige";
            this.lb_guige.Size = new System.Drawing.Size(41, 12);
            this.lb_guige.TabIndex = 35;
            this.lb_guige.Text = "规格：";
            // 
            // lb_danwei
            // 
            this.lb_danwei.AutoSize = true;
            this.lb_danwei.Location = new System.Drawing.Point(668, 262);
            this.lb_danwei.Name = "lb_danwei";
            this.lb_danwei.Size = new System.Drawing.Size(41, 12);
            this.lb_danwei.TabIndex = 36;
            this.lb_danwei.Text = "单位：";
            // 
            // txt_guige
            // 
            this.txt_guige.Location = new System.Drawing.Point(737, 216);
            this.txt_guige.Name = "txt_guige";
            this.txt_guige.Size = new System.Drawing.Size(100, 21);
            this.txt_guige.TabIndex = 37;
            // 
            // txt_danwei
            // 
            this.txt_danwei.Location = new System.Drawing.Point(737, 259);
            this.txt_danwei.Name = "txt_danwei";
            this.txt_danwei.Size = new System.Drawing.Size(100, 21);
            this.txt_danwei.TabIndex = 38;
            // 
            // txt_danjia
            // 
            this.txt_danjia.Location = new System.Drawing.Point(522, 216);
            this.txt_danjia.Name = "txt_danjia";
            this.txt_danjia.Size = new System.Drawing.Size(100, 21);
            this.txt_danjia.TabIndex = 39;
            // 
            // txt_bingrenleixing
            // 
            this.txt_bingrenleixing.Location = new System.Drawing.Point(737, 308);
            this.txt_bingrenleixing.Name = "txt_bingrenleixing";
            this.txt_bingrenleixing.Size = new System.Drawing.Size(100, 21);
            this.txt_bingrenleixing.TabIndex = 40;
            // 
            // lb_bingrenleixing
            // 
            this.lb_bingrenleixing.AutoSize = true;
            this.lb_bingrenleixing.Location = new System.Drawing.Point(668, 311);
            this.lb_bingrenleixing.Name = "lb_bingrenleixing";
            this.lb_bingrenleixing.Size = new System.Drawing.Size(65, 12);
            this.lb_bingrenleixing.TabIndex = 41;
            this.lb_bingrenleixing.Text = "病人类型：";
            // 
            // lb_shifoubaoxiao
            // 
            this.lb_shifoubaoxiao.AutoSize = true;
            this.lb_shifoubaoxiao.Location = new System.Drawing.Point(433, 262);
            this.lb_shifoubaoxiao.Name = "lb_shifoubaoxiao";
            this.lb_shifoubaoxiao.Size = new System.Drawing.Size(65, 12);
            this.lb_shifoubaoxiao.TabIndex = 42;
            this.lb_shifoubaoxiao.Text = "是否报销：";
            // 
            // lb_ruyuanriqi
            // 
            this.lb_ruyuanriqi.AutoSize = true;
            this.lb_ruyuanriqi.Location = new System.Drawing.Point(670, 103);
            this.lb_ruyuanriqi.Name = "lb_ruyuanriqi";
            this.lb_ruyuanriqi.Size = new System.Drawing.Size(65, 12);
            this.lb_ruyuanriqi.TabIndex = 43;
            this.lb_ruyuanriqi.Text = "入院日期：";
            // 
            // txt_ruyuanriqi
            // 
            this.txt_ruyuanriqi.Location = new System.Drawing.Point(737, 101);
            this.txt_ruyuanriqi.Name = "txt_ruyuanriqi";
            this.txt_ruyuanriqi.Size = new System.Drawing.Size(100, 21);
            this.txt_ruyuanriqi.TabIndex = 44;
            // 
            // txt_fashengri
            // 
            this.txt_fashengri.Location = new System.Drawing.Point(292, 262);
            this.txt_fashengri.Name = "txt_fashengri";
            this.txt_fashengri.Size = new System.Drawing.Size(100, 21);
            this.txt_fashengri.TabIndex = 45;
            // 
            // bt_gufei
            // 
            this.bt_gufei.Location = new System.Drawing.Point(547, 40);
            this.bt_gufei.Name = "bt_gufei";
            this.bt_gufei.Size = new System.Drawing.Size(75, 23);
            this.bt_gufei.TabIndex = 46;
            this.bt_gufei.Text = "固费";
            this.bt_gufei.UseVisualStyleBackColor = true;
            this.bt_gufei.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_qingchu
            // 
            this.bt_qingchu.Location = new System.Drawing.Point(634, 40);
            this.bt_qingchu.Name = "bt_qingchu";
            this.bt_qingchu.Size = new System.Drawing.Size(75, 23);
            this.bt_qingchu.TabIndex = 47;
            this.bt_qingchu.Text = "清除";
            this.bt_qingchu.UseVisualStyleBackColor = true;
            this.bt_qingchu.Click += new System.EventHandler(this.button2_Click);
            // 
            // bt_tianjia
            // 
            this.bt_tianjia.Location = new System.Drawing.Point(724, 40);
            this.bt_tianjia.Name = "bt_tianjia";
            this.bt_tianjia.Size = new System.Drawing.Size(75, 23);
            this.bt_tianjia.TabIndex = 48;
            this.bt_tianjia.Text = "添加";
            this.bt_tianjia.UseVisualStyleBackColor = true;
            this.bt_tianjia.Click += new System.EventHandler(this.button3_Click);
            // 
            // bt_shanchu
            // 
            this.bt_shanchu.Location = new System.Drawing.Point(814, 40);
            this.bt_shanchu.Name = "bt_shanchu";
            this.bt_shanchu.Size = new System.Drawing.Size(75, 23);
            this.bt_shanchu.TabIndex = 49;
            this.bt_shanchu.Text = "删除";
            this.bt_shanchu.UseVisualStyleBackColor = true;
            // 
            // bt_caoyao
            // 
            this.bt_caoyao.Location = new System.Drawing.Point(456, 39);
            this.bt_caoyao.Name = "bt_caoyao";
            this.bt_caoyao.Size = new System.Drawing.Size(75, 23);
            this.bt_caoyao.TabIndex = 50;
            this.bt_caoyao.Text = "草药";
            this.bt_caoyao.UseVisualStyleBackColor = true;
            // 
            // lb_jiaokuanjine
            // 
            this.lb_jiaokuanjine.AutoSize = true;
            this.lb_jiaokuanjine.Location = new System.Drawing.Point(23, 398);
            this.lb_jiaokuanjine.Name = "lb_jiaokuanjine";
            this.lb_jiaokuanjine.Size = new System.Drawing.Size(65, 12);
            this.lb_jiaokuanjine.TabIndex = 51;
            this.lb_jiaokuanjine.Text = "交款金额：";
            // 
            // lb_shengyujine
            // 
            this.lb_shengyujine.AutoSize = true;
            this.lb_shengyujine.Location = new System.Drawing.Point(218, 398);
            this.lb_shengyujine.Name = "lb_shengyujine";
            this.lb_shengyujine.Size = new System.Drawing.Size(65, 12);
            this.lb_shengyujine.TabIndex = 52;
            this.lb_shengyujine.Text = "剩余金额：";
            // 
            // lb_huafeijine
            // 
            this.lb_huafeijine.AutoSize = true;
            this.lb_huafeijine.Location = new System.Drawing.Point(435, 397);
            this.lb_huafeijine.Name = "lb_huafeijine";
            this.lb_huafeijine.Size = new System.Drawing.Size(65, 12);
            this.lb_huafeijine.TabIndex = 53;
            this.lb_huafeijine.Text = "花费金额：";
            // 
            // lb_xiaoji
            // 
            this.lb_xiaoji.AutoSize = true;
            this.lb_xiaoji.Location = new System.Drawing.Point(668, 397);
            this.lb_xiaoji.Name = "lb_xiaoji";
            this.lb_xiaoji.Size = new System.Drawing.Size(41, 12);
            this.lb_xiaoji.TabIndex = 54;
            this.lb_xiaoji.Text = "小计：";
            // 
            // txt_jiaokuanjine
            // 
            this.txt_jiaokuanjine.Location = new System.Drawing.Point(81, 395);
            this.txt_jiaokuanjine.Name = "txt_jiaokuanjine";
            this.txt_jiaokuanjine.Size = new System.Drawing.Size(100, 21);
            this.txt_jiaokuanjine.TabIndex = 55;
            // 
            // txt_shengyujine
            // 
            this.txt_shengyujine.Location = new System.Drawing.Point(292, 394);
            this.txt_shengyujine.Name = "txt_shengyujine";
            this.txt_shengyujine.Size = new System.Drawing.Size(100, 21);
            this.txt_shengyujine.TabIndex = 56;
            // 
            // txt_huafeijine
            // 
            this.txt_huafeijine.Location = new System.Drawing.Point(522, 395);
            this.txt_huafeijine.Name = "txt_huafeijine";
            this.txt_huafeijine.Size = new System.Drawing.Size(100, 21);
            this.txt_huafeijine.TabIndex = 57;
            // 
            // txt_xiaoji
            // 
            this.txt_xiaoji.Location = new System.Drawing.Point(737, 394);
            this.txt_xiaoji.Name = "txt_xiaoji";
            this.txt_xiaoji.Size = new System.Drawing.Size(100, 21);
            this.txt_xiaoji.TabIndex = 58;
            // 
            // bt_baocun
            // 
            this.bt_baocun.Location = new System.Drawing.Point(904, 40);
            this.bt_baocun.Name = "bt_baocun";
            this.bt_baocun.Size = new System.Drawing.Size(75, 23);
            this.bt_baocun.TabIndex = 59;
            this.bt_baocun.Text = "保存";
            this.bt_baocun.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.日期,
            this.Column7,
            this.时间,
            this.类别,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column8});
            this.dataGridView1.Location = new System.Drawing.Point(23, 452);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(939, 182);
            this.dataGridView1.TabIndex = 60;
            // 
            // 日期
            // 
            this.日期.HeaderText = "日期";
            this.日期.Name = "日期";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "金额";
            this.Column7.Name = "Column7";
            // 
            // 时间
            // 
            this.时间.HeaderText = "时间";
            this.时间.Name = "时间";
            // 
            // 类别
            // 
            this.类别.HeaderText = "类型";
            this.类别.Name = "类别";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "代码";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "名称";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "规格";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "单价";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "数量";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "报销标志";
            this.Column6.Name = "Column6";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "医生";
            this.Column8.Name = "Column8";
            // 
            // 费用补账处理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 638);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bt_baocun);
            this.Controls.Add(this.txt_xiaoji);
            this.Controls.Add(this.txt_huafeijine);
            this.Controls.Add(this.txt_shengyujine);
            this.Controls.Add(this.txt_jiaokuanjine);
            this.Controls.Add(this.lb_xiaoji);
            this.Controls.Add(this.lb_huafeijine);
            this.Controls.Add(this.lb_shengyujine);
            this.Controls.Add(this.lb_jiaokuanjine);
            this.Controls.Add(this.bt_caoyao);
            this.Controls.Add(this.bt_shanchu);
            this.Controls.Add(this.bt_tianjia);
            this.Controls.Add(this.bt_qingchu);
            this.Controls.Add(this.bt_gufei);
            this.Controls.Add(this.txt_fashengri);
            this.Controls.Add(this.txt_ruyuanriqi);
            this.Controls.Add(this.lb_ruyuanriqi);
            this.Controls.Add(this.lb_shifoubaoxiao);
            this.Controls.Add(this.lb_bingrenleixing);
            this.Controls.Add(this.txt_bingrenleixing);
            this.Controls.Add(this.txt_danjia);
            this.Controls.Add(this.txt_danwei);
            this.Controls.Add(this.txt_guige);
            this.Controls.Add(this.lb_danwei);
            this.Controls.Add(this.lb_guige);
            this.Controls.Add(this.lb_jizhangkeshi);
            this.Controls.Add(this.lb_suoshubingqu);
            this.Controls.Add(this.lb_danjia);
            this.Controls.Add(this.lb_mingcheng);
            this.Controls.Add(this.lb_suoshukeshi);
            this.Controls.Add(this.lb_xingmin);
            this.Controls.Add(this.txt_suoshubingqu);
            this.Controls.Add(this.txt_jizhangkeshi);
            this.Controls.Add(this.txt_mingcheng);
            this.Controls.Add(this.txt_suoshukeshi);
            this.Controls.Add(this.txt_xingming);
            this.Controls.Add(this.txt_shifouzhuyuan);
            this.Controls.Add(this.txt_shifoubaoxiao);
            this.Controls.Add(this.txt_jine);
            this.Controls.Add(this.txt_shuruma);
            this.Controls.Add(this.txt_chuangweihao);
            this.Controls.Add(this.txt_zhuyuanhao);
            this.Controls.Add(this.txt_yisheng);
            this.Controls.Add(this.txt_leibei);
            this.Controls.Add(this.txt_bingqu);
            this.Controls.Add(this.txt_menzhenhao);
            this.Controls.Add(this.txt_shuliang);
            this.Controls.Add(this.lb_shifouzhuyuan);
            this.Controls.Add(this.lb_fashengri);
            this.Controls.Add(this.lb_jine);
            this.Controls.Add(this.lb_shuruma);
            this.Controls.Add(this.lb_chuangweihao);
            this.Controls.Add(this.lb_yisheng);
            this.Controls.Add(this.lb_shuliang);
            this.Controls.Add(this.lb_leibie);
            this.Controls.Add(this.lb_bingqu);
            this.Controls.Add(this.lb_zhuyuhao);
            this.Controls.Add(this.lb_menzhenhao);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "费用补账处理";
            this.Text = "费用补账处理";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 费用补账处理ToolStripMenuItem;
        private System.Windows.Forms.Label lb_menzhenhao;
        private System.Windows.Forms.Label lb_zhuyuhao;
        private System.Windows.Forms.Label lb_bingqu;
        private System.Windows.Forms.Label lb_leibie;
        private System.Windows.Forms.Label lb_shuliang;
        private System.Windows.Forms.Label lb_yisheng;
        private System.Windows.Forms.Label lb_chuangweihao;
        private System.Windows.Forms.Label lb_shuruma;
        private System.Windows.Forms.Label lb_jine;
        private System.Windows.Forms.Label lb_fashengri;
        private System.Windows.Forms.Label lb_shifouzhuyuan;
        private System.Windows.Forms.TextBox txt_shuliang;
        private System.Windows.Forms.TextBox txt_menzhenhao;
        private System.Windows.Forms.TextBox txt_bingqu;
        private System.Windows.Forms.TextBox txt_leibei;
        private System.Windows.Forms.TextBox txt_yisheng;
        private System.Windows.Forms.TextBox txt_zhuyuanhao;
        private System.Windows.Forms.TextBox txt_chuangweihao;
        private System.Windows.Forms.TextBox txt_shuruma;
        private System.Windows.Forms.TextBox txt_jine;
        private System.Windows.Forms.TextBox txt_shifoubaoxiao;
        private System.Windows.Forms.TextBox txt_shifouzhuyuan;
        private System.Windows.Forms.TextBox txt_xingming;
        private System.Windows.Forms.TextBox txt_suoshukeshi;
        private System.Windows.Forms.TextBox txt_mingcheng;
        private System.Windows.Forms.TextBox txt_jizhangkeshi;
        private System.Windows.Forms.TextBox txt_suoshubingqu;
        private System.Windows.Forms.Label lb_xingmin;
        private System.Windows.Forms.Label lb_suoshukeshi;
        private System.Windows.Forms.Label lb_mingcheng;
        private System.Windows.Forms.Label lb_danjia;
        private System.Windows.Forms.Label lb_suoshubingqu;
        private System.Windows.Forms.Label lb_jizhangkeshi;
        private System.Windows.Forms.Label lb_guige;
        private System.Windows.Forms.Label lb_danwei;
        private System.Windows.Forms.TextBox txt_guige;
        private System.Windows.Forms.TextBox txt_danwei;
        private System.Windows.Forms.TextBox txt_danjia;
        private System.Windows.Forms.TextBox txt_bingrenleixing;
        private System.Windows.Forms.Label lb_bingrenleixing;
        private System.Windows.Forms.Label lb_shifoubaoxiao;
        private System.Windows.Forms.Label lb_ruyuanriqi;
        private System.Windows.Forms.TextBox txt_ruyuanriqi;
        private System.Windows.Forms.TextBox txt_fashengri;
        private System.Windows.Forms.Button bt_gufei;
        private System.Windows.Forms.Button bt_qingchu;
        private System.Windows.Forms.Button bt_tianjia;
        private System.Windows.Forms.Button bt_shanchu;
        private System.Windows.Forms.Button bt_caoyao;
        private System.Windows.Forms.Label lb_jiaokuanjine;
        private System.Windows.Forms.Label lb_shengyujine;
        private System.Windows.Forms.Label lb_huafeijine;
        private System.Windows.Forms.Label lb_xiaoji;
        private System.Windows.Forms.TextBox txt_jiaokuanjine;
        private System.Windows.Forms.TextBox txt_shengyujine;
        private System.Windows.Forms.TextBox txt_huafeijine;
        private System.Windows.Forms.TextBox txt_xiaoji;
        private System.Windows.Forms.Button bt_baocun;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn 日期;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn 时间;
        private System.Windows.Forms.DataGridViewTextBoxColumn 类别;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
    }
}

